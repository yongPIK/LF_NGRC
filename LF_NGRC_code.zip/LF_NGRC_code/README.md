# LF-NGRC code (minimal submission package)

This package contains only the scripts and data needed to reproduce the
figures/tables of the paper: the data-generating scripts, the plotting
scripts, and the precomputed data used by the plotting scripts.

## Layout

```
LF_NGRC_code_min/
├── code/                       all Python scripts
│   └── outputs/
│       ├── sweeps/             per-seed raw results used by the figures
│       │   ├── j_J*.json       J sweep (Fig. 3c)
│       │   ├── ntraj_*.json    N_traj sweep (Fig. 6a)
│       │   ├── lamb_*.json     lambda sweep (Fig. 6b)
│       │   ├── dt_*.json       Delta t sweep (Fig. 6c)
│       │   ├── verify20/       independent-seed runs (ntr100, dt=5e-3)
│       │   └── d3_ablation/    spectral-penalty ablation, 20 seeds (Fig. 5)
│       ├── fine_dt_summary.json
│       └── figures/            PNG output folder
└── data/                       canonical precomputed arrays for plotting
```

## Quick start (figures only, from saved data; < 10 min)

```bash
cd code
python make_figures.py                 # Fig. 1, Fig. 2, Fig. 3(a,b), Fig. 7
python plot_j4.py                      # Fig. 3 (merged: basins + sources + p vs J)
python plot_sweeps.py                  # Fig. 6 (merged: N_traj + lambda + dt)
python plot_spectral_ablation.py       # Fig. 5 (spectral ablation, 20 seeds)
```

Outputs are written to `code/outputs/figures/` (and `figures/` for the
spectral-ablation figure).

## Full reruns (data generation)

| Script | Produces |
|---|---|
| `repro_catch22.py` | Catch-22 exact baseline (Table I) |
| `baseline_poly_rbf.py` | polynomial / random-RBF baselines (Table I, Fig. 1b,c) |
| `poly_rbf_seed_stats.py` | 20-seed poly/RBF statistics (Fig. 2) |
| `run_main_experiment.py` | main pendulum 20-seed results (Fig. 2 data) |
| `j4_experiment.py` | over-complete J=4 runs + nine-initialization test (Fig. 3) |
| `sensitivity_fixed_init.py` | sensitivity curve + fixed-attractor init (Fig. 4a) |
| `spectral_radius_diagnostics.py` | rho / sigma_min(I-J) at settling points (Sec. IV.C) |
| `sweep_pendulum.py` | parameter sweeps: `j`, `ntraj`, `lamb`, `dt` (Fig. 3c and Fig. 6) |
| `dt_onestep_fill.py` | one-step column of the Delta t sweep |
| `verify_new_seeds.py` | independent-seed verification (ntr100, dt=5e-3) |
| `fine_dt_baseline.py` | fine-step exact baseline (Table I last row) |
| `kuramoto_lf.py` | Kuramoto representative run (Fig. 7) |
| `kuramoto_multi_seed.py` | Kuramoto 20-seed statistics |
| `kuramoto_gamma_sweep_fix.py` | Kuramoto gamma sweep (Fig. 7d) |
| `mlp_baseline.py`, `mlp_multi_seed.py` | MLP baselines (Table IV, Fig. 2) |
| `spectral_ablation_compute.py` | spectral-penalty ablation data (Fig. 5) |

Shared modules: `rc_core.py`, `repro_catch22.py`, `lf_ngrc.py`,
`run_lfngrc.py`. Plotting scripts: `make_figures.py`, `plot_j4.py`,
`plot_sweeps.py`, `plot_spectral_ablation.py`.

## Environment

- Python >= 3.10; tested with 3.13.5, numpy 2.1.3, scipy 1.15.3,
  torch 2.12.0, matplotlib 3.10.0 (float64, CPU).
- On Windows, set `KMP_DUPLICATE_LIB_OK=TRUE` before importing torch.


