"""Parameter-dependence sweeps for the magnetic-pendulum LF-NGRC experiments.

Produces Catch-22-SI-style curves (error rate p vs a hyperparameter):
    j      -- p vs dictionary size J in {2,3,4,5}            (LF closed)
    ntraj  -- p vs number of training trajectories           (exact/LF/one-step/RBF)
    lamb   -- p vs ridge regularization lambda               (exact/LF/one-step)
    dt     -- p vs sampling interval Delta t                 (exact/LF closed)

Conventions:
  * 51x51 basin grid (consistent with the fine-step baseline), dt=0.01 unless
    the dt sweep, k=3, lambda=1e-4 unless the lambda sweep.
  * Training time is kept at 20 time units (ntrain = round(20/dt)) in the dt
    sweep; otherwise ntrain=2000.
  * Every (sweep, parameter, seed) result is saved immediately to
    code/outputs/sweeps/ so partial progress survives interruption.

Run:  python sweep_pendulum.py j 
      python sweep_pendulum.py ntraj 
      python sweep_pendulum.py lamb 
      python sweep_pendulum.py dt 
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time, json, argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import repro_catch22 as rp
from lf_ngrc import PointSourceFeatures, LFNGRC, detect_attractors
from run_lfngrc import make_data, train_exact, eval_basins

CODE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(CODE)
OUT = os.path.join(CODE, "outputs", "sweeps")

GRID = 51
DT0 = 0.01
K = 3
LAMB0 = 1e-4


def load_gt(grid=GRID):
    """Ground-truth basins on the 51x51 grid (cached)."""
    gt = np.load(os.path.join(PKG, "data", "gt_dt001.npy"))
    if gt.shape != (grid, grid):
        gt = rp.ground_truth_basins(np.linspace(-1.5, 1.5, grid),
                                    np.linspace(-1.5, 1.5, grid), dt=0.01)
    return gt


def build_val(seed, dt=DT0, n_val=3, n_steps=1200):
    vrng = np.random.default_rng(1000 + seed)
    vlist = []
    for _ in range(n_val):
        v0 = np.hstack([vrng.uniform(-1.5, 1.5, (1, 2)), np.zeros((1, 2))])
        vlist.append(rp.sample_trajectory(v0[0], dt, n_steps + K))
    return vlist


def fit_lf_closed(trajs, vlist, seed, J=3, lamb=LAMB0, init_centers=None,
                  init_attractors=True):
    rng = np.random.default_rng(seed)
    if init_centers is not None:
        dic = PointSourceFeatures(J, init_centers=init_centers)
    else:
        dic = PointSourceFeatures(J, rng=rng)
    model = LFNGRC(dic, K, lamb=lamb, seed=seed)
    hist, W = model.fit(trajs, vlist, rollout_steps=500, a1=1.0, a2=0.1,
                        a3=0.1, iters=1100, verbose=0, roll_min=30,
                        roll_growth=1.01, n_windows=6, two_phase=True,
                        phase1_iters=300, phase1_lr=0.01, phase2_lr=0.05,
                        init_attractors=init_attractors)
    return model, W, hist


def fit_lf_onestep(trajs, vlist, seed, J=3, lamb=LAMB0):
    rng = np.random.default_rng(seed)
    dic = PointSourceFeatures(J, rng=rng)
    model = LFNGRC(dic, K, lamb=lamb, seed=seed)
    _, W = model.fit(trajs, vlist, rollout_steps=50, a1=0.0, a2=0.0, a3=0.0,
                     iters=300, lr=0.01, verbose=0, roll_min=50,
                     roll_growth=1.0, n_windows=2, two_phase=False)
    return model, W


def p_of(model, W, dt, gt, grid=GRID):
    pred = eval_basins(W, model.feature_fn_numpy(), K, dt,
                       np.linspace(-1.5, 1.5, grid))
    p, _ = rp.error_rate(pred, gt)
    return float(p)


def save_result(sweep, key, seed, data):
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, f"{sweep}_{key}_s{seed}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"sweep": sweep, "key": key, "seed": seed, **data}, f,
                  indent=1)


def case_exists(sweep, key, seed):
    return os.path.exists(os.path.join(OUT, f"{sweep}_{key}_s{seed}.json"))


def run_j(seeds, force):
    gt = load_gt()
    for J in [2, 3, 4, 5]:
        for seed in seeds:
            key = f"J{J}"
            if not force and case_exists("j", key, seed):
                print(f"skip {key} s{seed}", flush=True)
                continue
            t0 = time.time()
            trajs, _, S0 = make_data(10, 2000, DT0, K, seed)
            vlist = build_val(seed)
            att = detect_attractors(trajs, K)
            if J <= 3:
                model, W, _ = fit_lf_closed(trajs, vlist, seed, J=J)
            else:
                rng = np.random.default_rng(1000 + seed)
                extra = rng.uniform(-1.0, 1.0, (J - 3, 2))
                init_c = np.vstack([att, extra])
                model, W, _ = fit_lf_closed(trajs, vlist, seed, J=J,
                                            init_centers=init_c,
                                            init_attractors=False)
            p = p_of(model, W, DT0, gt)
            src = np.min(np.linalg.norm(
                model.dict_np["centers"][:, None, :] - rp.MAGNETS[None, :, :],
                axis=-1), axis=1)
            save_result("j", key, seed, {"p": p, "centers": model.dict_np[
                "centers"].tolist(), "heights": model.dict_np[
                    "heights"].tolist(), "min_src_dist": src.tolist()})
            print(f"[J sweep] {key} s{seed} p={p:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)


def run_ntraj(seeds, force):
    gt = load_gt()
    for ntr in [1, 3, 10, 30, 100]:
        for seed in seeds:
            key = f"ntr{ntr}"
            if not force and case_exists("ntraj", key, seed):
                print(f"skip {key} s{seed}", flush=True)
                continue
            t0 = time.time()
            trajs, _, S0 = make_data(ntr, 2000, DT0, K, seed)
            vlist = build_val(seed)
            res = {}
            Wex = train_exact(trajs, K, DT0, LAMB0)
            pex, _ = rp.error_rate(
                eval_basins(Wex, lambda Z: rp.exact_features(Z, K), K, DT0,
                            np.linspace(-1.5, 1.5, GRID)), gt)
            res["exact"] = float(pex)
            print(f"[ntraj] {key} s{seed} exact p={pex:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)

            model, W, _ = fit_lf_closed(trajs, vlist, seed)
            res["lf_closed"] = p_of(model, W, DT0, gt)
            res["centers"] = model.dict_np["centers"].tolist()
            print(f"[ntraj] {key} s{seed} LF p={res['lf_closed']:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)

            model1, W1 = fit_lf_onestep(trajs, vlist, seed)
            res["lf_onestep"] = p_of(model1, W1, DT0, gt)
            print(f"[ntraj] {key} s{seed} one-step "
                  f"p={res['lf_onestep']:.4f} {time.time()-t0:.0f}s",
                  flush=True)

            rng = np.random.default_rng(seed)
            centers = rng.uniform(-1.5, 1.5, (100, 2))
            Wr = rp.train_ngrc(
                trajs, K, lambda Z: rp.rbf_features_map(Z, K, centers),
                LAMB0, DT0)
            pr, _ = rp.error_rate(
                eval_basins(Wr, lambda Z: rp.rbf_features_map(Z, K, centers),
                            K, DT0, np.linspace(-1.5, 1.5, GRID)), gt)
            res["rbf"] = float(pr)
            print(f"[ntraj] {key} s{seed} RBF p={pr:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)
            save_result("ntraj", key, seed, res)


def run_lamb(seeds, force):
    gt = load_gt()
    for lamb in [1e-6, 1e-4, 1e-2, 0.1, 1.0, 1e2]:
        for seed in seeds:
            key = f"l{lamb:g}"
            if not force and case_exists("lamb", key, seed):
                print(f"skip {key} s{seed}", flush=True)
                continue
            t0 = time.time()
            trajs, _, S0 = make_data(10, 2000, DT0, K, seed)
            vlist = build_val(seed)
            res = {}
            Wex = train_exact(trajs, K, DT0, lamb)
            pex, _ = rp.error_rate(
                eval_basins(Wex, lambda Z: rp.exact_features(Z, K), K, DT0,
                            np.linspace(-1.5, 1.5, GRID)), gt)
            res["exact"] = float(pex)
            print(f"[lamb] {key} s{seed} exact p={pex:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)

            model, W, _ = fit_lf_closed(trajs, vlist, seed, lamb=lamb)
            res["lf_closed"] = p_of(model, W, DT0, gt)
            print(f"[lamb] {key} s{seed} LF p={res['lf_closed']:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)

            model1, W1 = fit_lf_onestep(trajs, vlist, seed, lamb=lamb)
            res["lf_onestep"] = p_of(model1, W1, DT0, gt)
            print(f"[lamb] {key} s{seed} one-step "
                  f"p={res['lf_onestep']:.4f} {time.time()-t0:.0f}s",
                  flush=True)
            save_result("lamb", key, seed, res)


def run_dt(seeds, force):
    gt = load_gt()
    dts = [3.125e-4, 1.25e-3, 5e-3, 0.01, 0.02, 0.04]
    for dt in dts:
        ntrain = max(500, int(round(20.0 / dt)))
        for seed in seeds:
            key = f"dt{dt:g}"
            if not force and case_exists("dt", key, seed):
                print(f"skip {key} s{seed}", flush=True)
                continue
            t0 = time.time()
            trajs, _, S0 = make_data(10, ntrain, dt, K, seed)
            vlist = build_val(seed, dt=dt)
            res = {}
            Wex = train_exact(trajs, K, dt, LAMB0)
            pex, _ = rp.error_rate(
                eval_basins(Wex, lambda Z: rp.exact_features(Z, K), K, dt,
                            np.linspace(-1.5, 1.5, GRID)), gt)
            res["exact"] = float(pex)
            print(f"[dt] {key} s{seed} exact p={pex:.4f} "
                  f"{time.time()-t0:.0f}s", flush=True)
            if dt >= 1.25e-3:      # LF at the finest dt is prohibitively slow
                model, W, _ = fit_lf_closed(trajs, vlist, seed)
                res["lf_closed"] = p_of(model, W, dt, gt)
                print(f"[dt] {key} s{seed} LF p={res['lf_closed']:.4f} "
                      f"{time.time()-t0:.0f}s", flush=True)
            save_result("dt", key, seed, res)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sweep", choices=["j", "ntraj", "lamb", "dt"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    if args.sweep == "j":
        run_j(args.seeds, args.force)
    elif args.sweep == "ntraj":
        run_ntraj(args.seeds, args.force)
    elif args.sweep == "lamb":
        run_lamb(args.seeds, args.force)
    elif args.sweep == "dt":
        run_dt(args.seeds, args.force)
    print(f"sweep '{args.sweep}' done", flush=True)


if __name__ == "__main__":
    main()
