"""Reproduce the polynomial (Model I) and random-RBF (Model II) baselines.

Configurations follow Zhang & Cornelius (2023), Figs. 2-4 / Table 1:
  * dt = 0.01, k = 2, lambda = 1, Ntraj = 100, Ntrain = 5000
  * Model I  : all monomials of total degree 2..dmax=3 over the 8 delay states
  * Model II : NRBF=100 radial basis functions 1/(||r-c||^2+h^2)^{3/2},
               centers uniform in [-1.5,1.5]^2, h=0.2
Basins are evaluated on a 51x51 grid over [-1.5,1.5]^2 (T=100).
Expected output: p_poly ~ 0.99 (mostly divergence), p_rbf ~ 0.59.
"""

import os
import sys
import time
import json
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(outdir=None):
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    t0 = time.time()
    ntraj, ntrain, dt, lamb, k = 100, 5000, 0.01, 1.0, 2
    rng = np.random.default_rng(0)
    S0 = np.hstack([rng.uniform(-1.5, 1.5, (ntraj, 2)), np.zeros((ntraj, 2))])
    trajs = [rp.sample_trajectory(S0[i], dt, ntrain + k) for i in range(ntraj)]
    print(f"data ready {time.time()-t0:.0f}s", flush=True)

    Z = np.concatenate([rp.make_delay_states(S, k)[:-1] for S in trajs])
    Y = np.concatenate([S[k:] - S[k - 1 : -1] for S in trajs])

    grid = np.linspace(-1.5, 1.5, 51)
    gt_path = os.path.join(outdir, "gt_dt001.npy")
    if not os.path.exists(gt_path):
        alt = os.path.join(PKG, "data", "gt_dt001.npy")
        if os.path.exists(alt):
            gt_path = alt
    gt = np.load(gt_path) if os.path.exists(gt_path) else \
        rp.ground_truth_basins(grid, grid, dt=dt)
    if not os.path.exists(gt_path):
        np.save(gt_path, gt)

    def train_and_eval(feature_fn, name):
        G = feature_fn(Z)
        W = np.linalg.solve(G.T @ G + lamb * np.eye(G.shape[1]),
                            (G.T @ Y)).T
        pred = rp.predict_basins(W, feature_fn, k, grid, grid, dt)
        np.save(os.path.join(outdir, f"{name}_pred.npy"), pred)
        p, _ = rp.error_rate(pred, gt)
        print(f"{name}: p = {p:.4f}  unique "
              f"{np.unique(pred, return_counts=True)} "
              f"({time.time()-t0:.0f}s)", flush=True)
        return p

    # Model I: polynomials (dmax=3)
    p_poly = train_and_eval(lambda Zz: rp.poly_features(Zz, k, 3), "poly")
    # Model II: random RBF (centers drawn from the same rng, after S0)
    centers = rng.uniform(-1.5, 1.5, (100, 2))
    p_rbf = train_and_eval(lambda Zz: rp.rbf_features_map(Zz, k, centers),
                           "rbf")

    with open(os.path.join(outdir, "baseline_poly_rbf_summary.json"),
              "w") as f:
        json.dump({"p_poly": p_poly, "p_rbf": p_rbf}, f, indent=1)
    print(f"done in {time.time()-t0:.0f}s  p_poly={p_poly:.4f}  "
          f"p_rbf={p_rbf:.4f}")


if __name__ == "__main__":
    main()
