"""Fill the missing LF one-step column of the Delta-t sweep.

The Delta-t sweep currently stores exact and LF closed-loop error rates; this
helper trains the one-step-only model at the same Delta-t values and merges the
result into the existing JSON files, so all three methods share one common
Delta-t range.

Run:  python dt_onestep_fill.py
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import sys, time, json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sweep_pendulum as sp


def main():
    dts = [1.25e-3, 5e-3, 0.01, 0.02, 0.04]
    seeds = list(range(20))
    gt = sp.load_gt()
    for dt in dts:
        ntrain = max(500, int(round(20.0 / dt)))
        for seed in seeds:
            key = f"dt{dt:g}"
            path = os.path.join(sp.OUT, f"dt_{key}_s{seed}.json")
            if not os.path.exists(path):
                print(f"skip {key} s{seed} (no base file)", flush=True)
                continue
            with open(path, "r", encoding="utf-8") as f:
                res = json.load(f)
            if "lf_onestep" in res:
                print(f"skip {key} s{seed} (already filled)", flush=True)
                continue
            t0 = time.time()
            trajs, _, S0 = sp.make_data(10, ntrain, dt, sp.K, seed)
            vlist = sp.build_val(seed, dt=dt)
            model1, W1 = sp.fit_lf_onestep(trajs, vlist, seed)
            p1 = sp.p_of(model1, W1, dt, gt)
            res["lf_onestep"] = p1
            with open(path, "w", encoding="utf-8") as f:
                json.dump(res, f, indent=1)
            print(f"[dt-onestep] {key} s{seed} p={p1:.4f} "
                  f"({time.time()-t0:.0f}s)", flush=True)
    print("dt one-step fill done", flush=True)


if __name__ == "__main__":
    main()
