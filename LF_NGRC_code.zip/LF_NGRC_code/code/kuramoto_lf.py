"""Kuramoto ring (n oscillators): exact vs learnable-frequency NGRC basins.

System (Zhang & Cornelius Eq. 10):  theta_dot_i = sin(theta_{i+1}-theta_i)
+ sin(theta_{i-1}-theta_i), periodic boundary. Twisted-state basins labelled
by |winding number|. Readout nonlinearity: sin(gamma * Delta theta) with a
learnable frequency gamma (exact = 1).
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import json
import numpy as np
import torch
import torch.nn as nn


def kuramoto_rhs(th):
    """th: (..., n) phases. Ring dynamics."""
    return np.sin(np.roll(th, -1, axis=-1) - th) + \
        np.sin(np.roll(th, 1, axis=-1) - th)


def integrate_kuramoto(theta0, dt, tmax=100.0, internal_dt=0.002,
                       return_full=False):
    theta0 = np.atleast_2d(np.asarray(theta0, dtype=float))
    n = len(theta0)
    th = theta0.copy()
    steps = int(np.ceil(tmax / dt))
    n_in = 1 if dt <= internal_dt else int(round(dt / internal_dt))
    h = dt / n_in
    full = [th.copy()]
    for _ in range(steps):
        for _ in range(n_in):
            k1 = kuramoto_rhs(th)
            k2 = kuramoto_rhs(th + 0.5 * h * k1)
            k3 = kuramoto_rhs(th + 0.5 * h * k2)
            k4 = kuramoto_rhs(th + h * k3)
            th = th + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        full.append(th.copy())
    return np.stack(full, axis=0) if return_full else th


def winding_number(theta):
    """q = round(sum of phase diffs / 2pi)."""
    d = np.roll(theta, -1, axis=-1) - theta
    d = (d + np.pi) % (2 * np.pi) - np.pi
    return np.round(np.sum(d, axis=-1) / (2 * np.pi)).astype(int)


def make_delay(S, k):
    T = len(S)
    n = T - k + 1
    return np.column_stack([S[k - 1 - i : T - i] for i in range(k)])


def exact_features(Z, k):
    """sin(diff) for all directed edges at each delay. 1 bias + nk linear."""
    n = Z.shape[1] // k
    parts = [np.ones((len(Z), 1)), Z]
    for i in range(k):
        th = Z[:, i * n : (i + 1) * n]
        d1 = np.roll(th, -1, axis=-1) - th
        d2 = np.roll(th, 1, axis=-1) - th
        parts.append(np.sin(d1))
        parts.append(np.sin(d2))
    return np.hstack(parts)


class SineFrequencyFeatures(nn.Module):
    """sin(gamma * Delta theta) with learnable gamma."""

    def __init__(self, gamma0=1.3):
        super().__init__()
        self.logg = nn.Parameter(torch.tensor(np.log(gamma0), dtype=torch.float64))

    @property
    def gamma(self):
        return torch.exp(self.logg)

    def features(self, Z, k):
        n = Z.shape[1] // k
        parts = [torch.ones((len(Z), 1), dtype=Z.dtype, device=Z.device), Z]
        g = self.gamma
        for i in range(k):
            th = Z[:, i * n : (i + 1) * n]
            d1 = torch.roll(th, -1, dims=1) - th
            d2 = torch.roll(th, 1, dims=1) - th
            parts.append(torch.sin(g * d1))
            parts.append(torch.sin(g * d2))
        return torch.cat(parts, dim=1)


def ridge_weights(features, Y, lamb):
    m = features.shape[1]
    GG = features.T @ features
    GY = features.T @ Y
    return torch.linalg.solve(GG + lamb * torch.eye(m, dtype=features.dtype,
                                                    device=features.device),
                              GY).T


class KuramotoLF:
    def __init__(self, dictionary, k, lamb=1e-5):
        self.dictionary = dictionary
        self.k = k
        self.lamb = lamb
        self.W = None

    def fit(self, trajs, val_list, rollout_steps=300, iters=700, lr=0.05,
            verbose=100, roll_min=20, roll_growth=1.01, n_windows=5,
            phase1_iters=250, phase1_lr=0.02, clip_scale=0.5,
            rho_target=0.999, a1=1.0):
        dev = next(self.dictionary.parameters()).device
        k = self.k
        dtype = torch.float64
        Z = torch.cat([torch.tensor(make_delay(S, k)[:-1], dtype=dtype)
                       for S in trajs])
        Y = torch.cat([torch.tensor(S[k:] - S[k - 1 : -1], dtype=dtype)
                       for S in trajs])
        n = Z.shape[1] // k
        yvar = torch.mean(Y * Y).item()
        Vbufs = [torch.tensor(make_delay(Vv, k), dtype=dtype) for Vv in val_list]
        Vs = [torch.tensor(Vv, dtype=dtype) for Vv in val_list]

        win_starts = []
        for Vbuf in Vbufs:
            if Vbuf.shape[0] > rollout_steps:
                starts = list(range(0, Vbuf.shape[0] - rollout_steps,
                                    max(1, (Vbuf.shape[0] - rollout_steps) // n_windows)))
                win_starts.append(starts[:n_windows])
            else:
                win_starts.append([0])

        opt = torch.optim.Adam(self.dictionary.parameters(), lr=phase1_lr)
        sched = None
        hist = []
        roll_now = roll_min
        for it in range(iters):
            opt.zero_grad()
            G = self.dictionary.features(Z, k)
            W = ridge_weights(G, Y, self.lamb)
            self.W = W.detach()
            L_step = torch.mean((Y - G @ W.T) ** 2) / yvar
            in_phase1 = it < phase1_iters
            if in_phase1:
                L = L_step
                L_roll = torch.zeros((), dtype=dtype)
            else:
                if sched is None:
                    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                        opt, T_max=iters - phase1_iters,
                        eta_min=max(lr / 1000.0, 1e-7))
                errs = []
                for Vbuf, V, starts in zip(Vbufs, Vs, win_starts):
                    for s in starts:
                        buf = Vbuf[s : s + 1].clone()
                        Vtarget = V[k + s : k + s + roll_now]
                        for t in range(roll_now):
                            Gb = self.dictionary.features(buf, k)
                            xnew = buf[:, 0:n] + Gb @ W.T
                            e = xnew[0] - Vtarget[t]
                            errs.append(clip_scale * torch.tanh(e / clip_scale))
                            if t + 1 < roll_now:
                                buf[:, n:] = buf[:, :-n].clone()
                                buf[:, 0:n] = xnew
                L_roll = torch.mean(torch.stack(errs) ** 2) / yvar
                L = L_step + a1 * L_roll
            L.backward()
            torch.nn.utils.clip_grad_norm_(self.dictionary.parameters(), 10.0)
            opt.step()
            if sched is not None:
                sched.step()
            roll_now = min(rollout_steps, int(roll_now * roll_growth))
            hist.append((L.item(), L_step.item(),
                         L_roll.item() if not in_phase1 else 0.0))
            if verbose and (it % verbose == 0 or it == iters - 1):
                print(f"it {it:4d} L {L.item():.5f} step {L_step.item():.6f} "
                      f"roll {L_roll.item() if not in_phase1 else 0:.5f} "
                      f"gamma {self.dictionary.gamma.item():.5f}")
        with torch.no_grad():
            G = self.dictionary.features(Z, k)
            self.W = ridge_weights(G, Y, self.lamb).cpu().numpy()
        self.gamma_np = self.dictionary.gamma.item()
        return np.array(hist), self.W

    def feature_fn_numpy(self):
        k = self.k
        n = 9  # set below via closure

        def fn(Z, n_=None):
            nn_ = Z.shape[1] // k
            g = self.gamma_np
            parts = [np.ones((len(Z), 1)), Z]
            for i in range(k):
                th = Z[:, i * nn_ : (i + 1) * nn_]
                d1 = np.roll(th, -1, axis=-1) - th
                d2 = np.roll(th, 1, axis=-1) - th
                parts.append(np.sin(g * d1))
                parts.append(np.sin(g * d2))
            return np.hstack(parts)

        return fn


def sample_kuramoto(theta0, dt, n_samples, internal_dt=0.002):
    theta0 = np.asarray(theta0, dtype=float)
    steps = int(n_samples)
    th = theta0.copy()
    n_in = 1 if dt <= internal_dt else int(round(dt / internal_dt))
    h = dt / n_in
    out = np.empty((steps + 1, len(theta0)))
    out[0] = th
    for s in range(steps):
        for _ in range(n_in):
            k1 = kuramoto_rhs(th)
            k2 = kuramoto_rhs(th + 0.5 * h * k1)
            k3 = kuramoto_rhs(th + 0.5 * h * k2)
            k4 = kuramoto_rhs(th + h * k3)
            th = th + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        out[s + 1] = th
    return out


def predict_kuramoto_basins(W, fn, k, n, slice_base, P1, P2, dt, grid=101,
                            T=100.0, batch=4096):
    a = np.linspace(-np.pi, np.pi, grid)
    A1, A2 = np.meshgrid(a, a)
    flat = np.stack([A1.ravel(), A2.ravel()], axis=-1)
    starts = slice_base[None, :] + flat[:, :1] * P1[None, :] + flat[:, 1:] * P2[None, :]
    N = len(starts)
    labels = np.full(N, -1, dtype=int)
    steps = int(np.ceil(T / dt))
    for b0 in range(0, N, batch):
        buf = np.empty((min(batch, N - b0), k, n))
        b = starts[b0 : b0 + batch]
        nb = len(b)
        # warm-up: k states from the true system at t=0..(k-1)dt
        hist = np.empty((nb, k, n))
        s = b.copy()
        for j in range(k):
            hist[:, j, :] = s
            if j < k - 1:
                n_in = 1 if dt <= 0.002 else int(round(dt / 0.002))
                h = dt / n_in
                for _ in range(n_in):
                    k1 = kuramoto_rhs(s)
                    k2 = kuramoto_rhs(s + 0.5 * h * k1)
                    k3 = kuramoto_rhs(s + 0.5 * h * k2)
                    k4 = kuramoto_rhs(s + h * k3)
                    s = s + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        buf = hist[:, ::-1].copy()
        active = np.ones(nb, dtype=bool)
        for _ in range(steps):
            if not active.any():
                break
            idx = np.where(active)[0]
            sub = buf[idx]
            Z = sub.reshape(len(idx), k * n)
            G = fn(Z)
            xnew = sub[:, 0, :] + G @ W.T
            buf[idx, 1:] = sub[:, :-1]
            buf[idx, 0] = xnew
        r = buf[:, 0, :]
        q = winding_number(r)
        labels[b0 : b0 + nb] = np.abs(q)
    return labels.reshape(grid, grid), A1, A2


def ground_truth_kuramoto(slice_base, P1, P2, dt, grid=101, T=100.0, batch=4096):
    a = np.linspace(-np.pi, np.pi, grid)
    A1, A2 = np.meshgrid(a, a)
    flat = np.stack([A1.ravel(), A2.ravel()], axis=-1)
    starts = slice_base[None, :] + flat[:, :1] * P1[None, :] + flat[:, 1:] * P2[None, :]
    N = len(starts)
    labels = np.full(N, -1, dtype=int)
    steps = int(np.ceil(T / dt))
    for b0 in range(0, N, batch):
        b = starts[b0 : b0 + batch].copy()
        n_in = 1 if dt <= 0.002 else int(round(dt / 0.002))
        h = dt / n_in
        for _ in range(steps):
            for _ in range(n_in):
                k1 = kuramoto_rhs(b)
                k2 = kuramoto_rhs(b + 0.5 * h * k1)
                k3 = kuramoto_rhs(b + 0.5 * h * k2)
                k4 = kuramoto_rhs(b + h * k3)
                b = b + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        labels[b0 : b0 + batch] = np.abs(winding_number(b))
    return labels.reshape(grid, grid), A1, A2


# ---------------------------------------------------------------------------
# Driver: reproduce the Kuramoto section (Fig. 4) end to end.
# ---------------------------------------------------------------------------

def _train_ngrc_ridge(trajs, k, lamb, feature_fn):
    """Ridge NGRC readout for arbitrary (fixed) feature map."""
    GG = GY = None
    for S in trajs:
        Z = make_delay(S, k)[:-1]
        G = feature_fn(Z)
        Y = S[k:] - S[k - 1 : -1]
        if GG is None:
            m = G.shape[1]
            GG = np.zeros((m, m))
            GY = np.zeros((m, Y.shape[1]))
        GG += G.T @ G
        GY += G.T @ Y
    return np.linalg.solve(GG + lamb * np.eye(GG.shape[0]), GY).T


def _eval_slice(W, fn, k, n, slice_base, P1, P2, dt, grid=101):
    """Return only the label grid (predict returns labels, A1, A2)."""
    return predict_kuramoto_basins(W, fn, k, n, slice_base, P1, P2, dt,
                                   grid=grid)[0]


def main(ntraj=200, ntrain=3000, dt=0.01, k=2, lamb=1e-5, gamma0=1.3,
         grid=101, iters=1000, phase1_iters=250, rollout_steps=400,
         clip_scale=1.0, seed=0, outdir=None, n_val=3, verbose=50):
    """Train exact and LF-NGRC on the n=9 ring and save the Fig. 4 artifacts.

    Hyperparameters follow Table 4 of the paper (closed-loop 250/750
    iterations, maximum horizon 400, sigma=1.0). The 750-iteration
    closed-loop phase is required to reproduce the archived result
    gamma=1.00000008 with 99.0% basin accuracy (data/fig_gamma.npy,
    data/ku_lf_pred101.npy); shorter runs stall near gamma~0.996 with lower
    accuracy. Validation trajectories are drawn from the prediction slice
    theta0 + a1*P1 + a2*P2, as stated in Section 4.4.
    """
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    import time
    t0 = time.time()
    n = 9
    rng = np.random.default_rng(seed)
    S0 = rng.uniform(0.0, 2.0 * np.pi, (ntraj, n))
    tmax = (ntrain + k) * dt
    trajs = np.stack([integrate_kuramoto(th, dt, tmax=tmax,
                                         return_full=True)[:, 0, :]
                      for th in S0])
    print(f"data ready {time.time()-t0:.0f}s  trajs {trajs.shape}", flush=True)

    th0 = 2.0 * np.pi * 2 * np.arange(n) / n          # q=2 twisted state
    P1 = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1], dtype=float)
    P2 = np.array([0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=float)
    vrng = np.random.default_rng(1000 + seed)
    val_list = []
    for _ in range(n_val):
        a1, a2 = vrng.uniform(-np.pi, np.pi, 2)
        v0 = th0 + a1 * P1 + a2 * P2
        val_list.append(integrate_kuramoto(v0, dt,
                                           tmax=(1200 + k) * dt,
                                           return_full=True)[:, 0, :])

    # exact nonlinearity
    Wex = _train_ngrc_ridge(trajs, k, lamb,
                            lambda Z: exact_features(Z, k))
    print(f"exact trained {time.time()-t0:.0f}s", flush=True)

    # LF-NGRC learnable frequency (from gamma0)
    dic = SineFrequencyFeatures(gamma0=gamma0)
    model = KuramotoLF(dic, k, lamb=lamb)
    hist, Wlf = model.fit(trajs, val_list, rollout_steps=rollout_steps,
                          iters=iters, lr=0.05, verbose=verbose,
                          phase1_iters=phase1_iters, phase1_lr=0.02,
                          clip_scale=clip_scale, n_windows=5, a1=1.0)
    gamma = model.gamma_np
    print(f"LF trained gamma={gamma:.7f} {time.time()-t0:.0f}s", flush=True)

    # one-step-only regression
    dic1 = SineFrequencyFeatures(gamma0=gamma0)
    model1 = KuramotoLF(dic1, k, lamb=lamb)
    _, W1 = model1.fit(trajs, val_list, rollout_steps=rollout_steps,
                       iters=phase1_iters, lr=0.05, verbose=0,
                       phase1_iters=phase1_iters, phase1_lr=0.02,
                       clip_scale=clip_scale, n_windows=5, a1=1.0)
    gamma1 = model1.gamma_np
    print(f"one-step gamma={gamma1:.5f} {time.time()-t0:.0f}s", flush=True)

    # slice basins
    ku_gt, _, _ = ground_truth_kuramoto(th0, P1, P2, dt, grid=grid)
    ku_exact = _eval_slice(Wex, lambda Z: exact_features(Z, k), k, n,
                           th0, P1, P2, dt, grid=grid)
    ku_lf = _eval_slice(Wlf, model.feature_fn_numpy(), k, n,
                        th0, P1, P2, dt, grid=grid)
    pred1 = _eval_slice(W1, model1.feature_fn_numpy(), k, n,
                        th0, P1, P2, dt, grid=grid)
    acc_exact = float(np.mean(ku_exact == ku_gt))
    acc_lf = float(np.mean(ku_lf == ku_gt))
    acc1 = float(np.mean(pred1 == ku_gt))
    print(f"acc exact {acc_exact:.4f}  LF {acc_lf:.4f}  "
          f"one-step {acc1:.4f}  ({time.time()-t0:.0f}s)", flush=True)

    # gamma sensitivity sweep (same slice/eval settings as the main run)
    gams = np.array([0.5, 0.7, 0.8, 0.9, 0.95, 1.0, 1.05, 1.1, 1.2, 1.5])
    accs = []
    for g in gams:
        Wg = _train_ngrc_ridge(
            trajs, k, lamb,
            lambda Z, g_=g: _sine_features(Z, k, g_))
        pg = _eval_slice(Wg, lambda Z, g_=g: _sine_features(Z, k, g_),
                         k, n, th0, P1, P2, dt, grid=grid)
        accs.append(float(np.mean(pg == ku_gt)))
    print("gamma sweep peaks:", dict(zip(gams.tolist(),
                                         np.round(accs, 4).tolist())),
          flush=True)

    summary = {"gamma": gamma, "gamma_onestep": gamma1,
               "acc_exact": acc_exact, "acc_lf": acc_lf,
               "acc_onestep": acc1}
    with open(os.path.join(outdir, "kuramoto_summary.json"), "w") as f:
        json.dump(summary, f, indent=1)
    np.save(os.path.join(outdir, "ku_gt101.npy"), ku_gt)
    np.save(os.path.join(outdir, "ku_exact101.npy"), ku_exact)
    np.save(os.path.join(outdir, "ku_lf_pred101.npy"), ku_lf)
    np.save(os.path.join(outdir, "ku_lf_hist.npy"), np.asarray(hist))
    np.save(os.path.join(outdir, "fig_gamma.npy"), np.array([gamma]))
    np.save(os.path.join(outdir, "ku_gamma_sweep.npy"),
            np.stack([gams, np.array(accs)]))
    print(f"saved ku_* artifacts to {outdir}  ({time.time()-t0:.0f}s)",
          flush=True)
    return summary


def _sine_features(Z, k, gamma):
    """sin(gamma * Delta theta) features for a FIXED gamma (numpy)."""
    n = Z.shape[1] // k
    parts = [np.ones((len(Z), 1)), Z]
    for i in range(k):
        th = Z[:, i * n : (i + 1) * n]
        d1 = np.roll(th, -1, axis=-1) - th
        d2 = np.roll(th, 1, axis=-1) - th
        parts.append(np.sin(gamma * d1))
        parts.append(np.sin(gamma * d2))
    return np.hstack(parts)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--ntraj", type=int, default=200)
    ap.add_argument("--ntrain", type=int, default=3000)
    ap.add_argument("--grid", type=int, default=101)
    ap.add_argument("--iters", type=int, default=1000)
    ap.add_argument("--phase1", type=int, default=250)
    ap.add_argument("--rollout", type=int, default=400)
    ap.add_argument("--clip", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default=None)
    ap.add_argument("--verbose", type=int, default=50)
    args = ap.parse_args()
    main(ntraj=args.ntraj, ntrain=args.ntrain, grid=args.grid,
         iters=args.iters, phase1_iters=args.phase1,
         rollout_steps=args.rollout, clip_scale=args.clip,
         seed=args.seed, outdir=args.out, verbose=args.verbose)
