"""
Run:  python verify_new_seeds.py ntr100
      python verify_new_seeds.py dt125
      python verify_new_seeds.py dt5
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import sys, time, json, argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sweep_pendulum as sp

CODE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(CODE, "outputs", "sweeps", "verify20")
SEEDS = list(range(20, 40))


def run_case(tag, ntraj, ntrain, dt, seed):
    t0 = time.time()
    trajs, _, S0 = sp.make_data(ntraj, ntrain, dt, sp.K, seed)
    vlist = sp.build_val(seed, dt=dt)
    model, W, _ = sp.fit_lf_closed(trajs, vlist, seed)
    p = sp.p_of(model, W, dt, sp.load_gt())
    res = {"tag": tag, "seed": seed, "p_lf_closed": float(p),
           "centers": model.dict_np["centers"].tolist(),
           "heights": model.dict_np["heights"].tolist()}
    with open(os.path.join(OUT, f"{tag}_s{seed}.json"), "w",
              encoding="utf-8") as f:
        json.dump(res, f, indent=1)
    print(f"[{tag}] s{seed} p={p:.4f} ({time.time()-t0:.0f}s)", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=["ntr100", "dt125", "dt5"])
    args = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    if args.case == "ntr100":
        for s in SEEDS:
            run_case("ntr100", 100, 2000, 0.01, s)
    elif args.case == "dt125":
        for s in SEEDS:
            run_case("dt125", 10, int(round(20 / 1.25e-3)), 1.25e-3, s)
    elif args.case == "dt5":
        for s in SEEDS:
            run_case("dt5", 10, int(round(20 / 5e-3)), 5e-3, s)
    print(f"{args.case} verify done", flush=True)


if __name__ == "__main__":
    main()
