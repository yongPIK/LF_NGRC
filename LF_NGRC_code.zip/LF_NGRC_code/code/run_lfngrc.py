"""Main LF-NGRC experiments on the magnetic pendulum basin task."""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp
from lf_ngrc import (
    PointSourceFeatures, RBFDictionaryFeatures, LFNGRC,
)

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def make_data(ntraj, ntrain, dt, k, seed, val_len=900, val_seed=12345):
    rng = np.random.default_rng(seed)
    S0 = np.hstack([rng.uniform(-1.5, 1.5, (ntraj, 2)), np.zeros((ntraj, 2))])
    trajs = rp.sample_trajectories(S0, dt, ntrain + k)
    vrng = np.random.default_rng(val_seed)
    v0 = np.hstack([vrng.uniform(-1.5, 1.5, (1, 2)), np.zeros((1, 2))])
    val_traj = rp.sample_trajectory(v0[0], dt, val_len + k)
    return trajs, val_traj, S0


def train_exact(trajs, k, dt, lamb):
    GG = None
    GY = None
    for S in trajs:
        Z = rp.make_delay_states(S, k)[:-1]
        G = rp.exact_features(Z, k)
        Y = S[k:] - S[k - 1 : -1]
        if GG is None:
            GG = np.zeros((G.shape[1], G.shape[1]))
            GY = np.zeros((G.shape[1], 4))
        GG += G.T @ G
        GY += G.T @ Y
    return np.linalg.solve(GG + lamb * np.eye(GG.shape[0]), GY).T


def eval_basins(W, fn, k, dt, grid, T=100.0):
    return rp.predict_basins(W, fn, k, grid, grid, dt, T=T)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--ntraj", type=int, default=10)
    p.add_argument("--ntrain", type=int, default=2000)
    p.add_argument("--dt", type=float, default=0.01)
    p.add_argument("--k", type=int, default=3)
    p.add_argument("--lamb", type=float, default=1e-4)
    p.add_argument("--J", type=int, default=3)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--iters", type=int, default=800,
                   help="total iterations; with --closed the last "
                        "iters-phase1_iters are closed-loop")
    p.add_argument("--lr", type=float, default=0.05)
    p.add_argument("--grid", type=int, default=101)
    p.add_argument("--dict", choices=["point", "rbf"], default="point")
    p.add_argument("--closed", type=int, default=1, help="use closed-loop losses")
    p.add_argument("--out",
                   default=os.path.join(os.path.dirname(
                       os.path.abspath(__file__)), "outputs"))
    args = p.parse_args()
    os.makedirs(args.out, exist_ok=True)
    tag = (f"{args.dict}_J{args.J}_k{args.k}_nt{args.ntraj}_ntr{args.ntrain}"
           f"_l{args.lamb}_s{args.seed}_c{args.closed}")

    t0 = time.time()
    trajs, val_traj, S0 = make_data(args.ntraj, args.ntrain, args.dt, args.k,
                                    args.seed)
    print(f"data ready {time.time()-t0:.1f}s  traj shapes {trajs.shape}")

    # exact baseline with same data
    Wex = train_exact(trajs, args.k, args.dt, args.lamb)
    print(f"exact trained {time.time()-t0:.1f}s")

    rng = np.random.default_rng(args.seed)
    if args.dict == "point":
        dic = PointSourceFeatures(args.J, rng=rng)
    else:
        dic = RBFDictionaryFeatures(args.J, rng=rng)
    model = LFNGRC(dic, args.k, lamb=args.lamb, seed=args.seed)
    a1 = 1.0 if args.closed else 0.0
    a2 = 0.1 if args.closed else 0.0
    a3 = 0.1 if args.closed else 0.0
    phase1_iters = (min(300, max(100, args.iters - 100)) if args.closed
                    else 0)
    hist, W = model.fit(trajs, val_traj, rollout_steps=400, a1=a1, a2=a2,
                        a3=a3, iters=args.iters, lr=args.lr, verbose=50,
                        two_phase=bool(args.closed),
                        phase1_iters=phase1_iters, phase2_lr=args.lr)
    np.save(os.path.join(args.out, f"hist_{tag}.npy"), hist)
    np.save(os.path.join(args.out, f"W_{tag}.npy"), W)
    print(f"LF trained {time.time()-t0:.1f}s  learned centers:\n"
          f"{model.dict_np['centers']}\nheights {model.dict_np['heights']}")

    grid = np.linspace(-1.5, 1.5, args.grid)
    fn = model.feature_fn_numpy()
    pred_lf = eval_basins(W, fn, args.k, args.dt, grid)
    np.save(os.path.join(args.out, f"pred_{tag}.npy"), pred_lf)
    pred_ex = eval_basins(Wex, lambda Z: rp.exact_features(Z, args.k),
                          args.k, args.dt, grid)
    np.save(os.path.join(args.out, f"pred_exact_{tag}.npy"), pred_ex)
    print(f"basins predicted {time.time()-t0:.1f}s")

    gt_path = os.path.join(PKG, "data", "gt_dt001.npy")
    gt = (np.load(gt_path) if (args.grid == 51 and os.path.exists(gt_path))
          else rp.ground_truth_basins(grid, grid, dt=args.dt))
    p_lf, _ = rp.error_rate(pred_lf, gt)
    p_ex, _ = rp.error_rate(pred_ex, gt)
    print(f"LF-NGRC p = {p_lf:.4f}   exact p = {p_ex:.4f}")
    print(f"LF unique {np.unique(pred_lf, return_counts=True)}")
    np.save(os.path.join(args.out, f"p_{tag}.npy"), np.array([p_lf, p_ex]))
