"""Quick multi-seed statistics for Model I (polynomial) and Model II (RBF).

Preliminary measurement (10 seeds by default, 101x101 grid) used to report a
small-but-nonzero std for the polynomial baseline in Table 2; the formal 20-seed
run stays in the pending batch. Saves code/outputs/sweeps/poly_rbf_seed_stats.json.

Run:  python poly_rbf_seed_stats.py --seeds 10 --grid 101
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import sys, time, json, argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import repro_catch22 as rp

CODE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(CODE)
OUT = os.path.join(CODE, "outputs", "sweeps")


def main(n_seeds, grid):
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    ntraj, ntrain, dt, lamb, k = 100, 5000, 0.01, 1.0, 2
    gridv = np.linspace(-1.5, 1.5, grid)
    gt = np.load(os.path.join(PKG, "data", "gt101.npy"))
    if gt.shape != (grid, grid):
        gt = rp.ground_truth_basins(gridv, gridv, dt=dt)

    p_poly, p_rbf = [], []
    for seed in range(n_seeds):
        rng = np.random.default_rng(seed)
        S0 = np.hstack([rng.uniform(-1.5, 1.5, (ntraj, 2)),
                        np.zeros((ntraj, 2))])
        trajs = [rp.sample_trajectory(S0[i], dt, ntrain + k)
                 for i in range(ntraj)]
        Z = np.concatenate([rp.make_delay_states(S, k)[:-1] for S in trajs])
        Y = np.concatenate([S[k:] - S[k - 1 : -1] for S in trajs])
        centers = rng.uniform(-1.5, 1.5, (100, 2))

        def eval_model(fn, name):
            G = fn(Z)
            W = np.linalg.solve(G.T @ G + lamb * np.eye(G.shape[1]),
                                (G.T @ Y)).T
            pred = rp.predict_basins(W, fn, k, gridv, gridv, dt)
            p, _ = rp.error_rate(pred, gt)
            print(f"[seed {seed}] {name} p={p:.4f} ({time.time()-t0:.0f}s)",
                  flush=True)
            return float(p)

        p_poly.append(eval_model(lambda Zz: rp.poly_features(Zz, k, 3), "poly"))
        p_rbf.append(eval_model(
            lambda Zz: rp.rbf_features_map(Zz, k, centers), "rbf"))

    res = {
        "n_seeds": n_seeds,
        "grid": grid,
        "p_poly": p_poly,
        "p_rbf": p_rbf,
        "mean_poly": float(np.mean(p_poly)),
        "std_poly": float(np.std(p_poly, ddof=1)),
        "mean_rbf": float(np.mean(p_rbf)),
        "std_rbf": float(np.std(p_rbf, ddof=1)),
    }
    path = os.path.join(OUT, "poly_rbf_seed_stats.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1)
    print(f"saved {path}  poly {res['mean_poly']:.4f}±{res['std_poly']:.4f}  "
          f"rbf {res['mean_rbf']:.4f}±{res['std_rbf']:.4f}  "
          f"({time.time()-t0:.0f}s)", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--grid", type=int, default=101)
    args = ap.parse_args()
    main(args.seeds, args.grid)
