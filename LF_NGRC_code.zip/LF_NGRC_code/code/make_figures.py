"""Generate publication figures for the LF-NGRC paper."""

import os, sys, json
import numpy as np
import matplotlib
if os.environ.get("LF_HEADLESS") == "1":
    matplotlib.use("Agg")          # headless mode: save only, no display
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp

# Resolve paths relative to the package (works from any CWD)
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
DATA = os.environ.get("LF_DATA", os.path.join(PKG, "data"))
OUT = os.environ.get(
    "LF_FIGOUT",
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 "outputs", "figures"))
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.dpi": 150,
})


# ---------------------------------------------------------------------------
# Fig 1: magnetic pendulum basins
# ---------------------------------------------------------------------------

def pendulum_cmap():
    return ListedColormap(["black", "#2166ac", "#fdae61", "#1a9850"])


def plot_basin(ax, img, title, vmax=2):
    cmap = pendulum_cmap()
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5, 2.5], cmap.N)
    img2 = np.where(img == -2, -1, img)
    im = ax.imshow(img2, origin="lower", extent=[-1.5, 1.5, -1.5, 1.5],
                   cmap=cmap, norm=norm)
    ax.set_title(title)
    ax.set_xlabel("$x_0$")
    ax.set_ylabel("$y_0$")
    ax.set_xticks([-1.5, 0, 1.5])
    ax.set_yticks([-1.5, 0, 1.5])
    return im


def fig1():
    gt = np.load(os.path.join(DATA, "gt101.npy"))
    exact = np.load(os.path.join(DATA, "fig_exact101.npy"))
    lf = np.load(os.path.join(DATA, "fig_lf101.npy"))
    poly = np.load(os.path.join(DATA, "poly_pred.npy"))
    rbf = np.load(os.path.join(DATA, "rbf_pred.npy"))
    fig, axes = plt.subplots(1, 5, figsize=(15, 3.2), constrained_layout=True)
    plot_basin(axes[0], gt, "Ground truth")
    plot_basin(axes[1], poly, "Polynomial")
    plot_basin(axes[2], rbf, "Random RBF")
    plot_basin(axes[3], exact, "Exact nonlinearity")
    im = plot_basin(axes[4], lf, "LF-NGRC (learned)")
    cbar = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02, ticks=[0, 1, 2])
    cbar.ax.set_yticklabels(["magnet 1", "magnet 2", "magnet 3"])
    cbar.ax.tick_params(labelsize=8)
    fig.suptitle("Magnetic pendulum basins ($\\Delta t=0.01$, $k=3$, $N_\\mathrm{traj}=10$)")
    fig.savefig(os.path.join(OUT, "fig1_pendulum_basins.png"))
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig 2: error-rate bar chart
# ---------------------------------------------------------------------------

def fig2():
    summary = json.load(open(os.path.join(DATA, "summary.json")))
    models = ["Polynomial\n(NGRC-I)", "Random RBF\n(NGRC-II)",
              "MLP map\none-step", "MLP map\nclosed-loop",
              "Exact\nnonlin.", "LF-NGRC\none-step",
              "LF-NGRC\nrandom init", "LF-NGRC\nclosed loop"]
    arr_exact = np.array([summary[s]["exact"] for s in summary])
    arr_1s = np.array([summary[s]["lf_onestep"] for s in summary])
    arr_ri = np.array([summary[s]["lf_randominit"] for s in summary])
    arr_cl = np.array([summary[s]["lf_closed"] for s in summary])
    # Model I/II: 20-seed stats (SI sweep) with fallback to the single values
    pr_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "outputs", "sweeps", "poly_rbf_seed_stats.json")
    pr = {}
    if os.path.exists(pr_path):
        pr = json.load(open(pr_path))
    poly_mean = pr.get("mean_poly", 0.9889)
    poly_std = pr.get("std_poly", 0.0)
    rbf_mean = pr.get("mean_rbf", 0.5855)
    rbf_std = pr.get("std_rbf", 0.0)
    # MLP: 5-seed stats (SI sweep) with fallback to the single values
    mlp = {}
    mlp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "outputs", "sweeps",
                            "mlp_multi_seed_summary.json")
    if not os.path.exists(mlp_path):
        alt = os.path.join(DATA, "mlp_results.json")
        if os.path.exists(alt):
            mlp = json.load(open(alt))
        p_mlp1 = mlp.get("p_onestep", 0.8062)
        p_mlp2 = mlp.get("p_closedloop", 0.7283)
        s_mlp1 = s_mlp2 = 0.0
    else:
        mlp = json.load(open(mlp_path))
        p_mlp1 = mlp.get("p_onestep_mean", 0.8556)
        p_mlp2 = mlp.get("p_closedloop_mean", 0.8951)
        s_mlp1 = mlp.get("p_onestep_std", 0.0)
        s_mlp2 = mlp.get("p_closedloop_std", 0.0)
    data = [[poly_mean, poly_std], [rbf_mean, rbf_std],
            [p_mlp1, s_mlp1], [p_mlp2, s_mlp2],
            arr_exact, arr_1s, arr_ri, arr_cl]
    means = [np.mean(d) if isinstance(d, np.ndarray) else d[0]
             for d in data]
    errs = [np.std(d) if isinstance(d, np.ndarray) else d[1]
            for d in data]
    fig, ax = plt.subplots(figsize=(10.0, 3.8))
    fig.subplots_adjust(left=0.07, right=0.78, top=0.86, bottom=0.17)
    bars = ax.bar(range(len(models)), means, yerr=errs, capsize=4,
                  color=["#8c8c8c", "#8c8c8c", "#b2182b", "#d6604d",
                         "#2166ac", "#fdae61", "#d6604d", "#1a9850"])
    ax.axhline(2 / 3, ls="--", color="k", lw=1, label="random guess")
    ax.axhline(0.45, ls=":", color="k", lw=1, label="useful threshold ($p=0.45$)")
    for b, m in zip(bars, means):
        ax.text(b.get_x() + b.get_width() / 2, m + 0.02, f"{m:.2f}",
                ha="center", fontsize=9)
    ax.set_xticks(range(len(models)))
    ax.set_xticklabels(models)
    ax.set_ylabel("basin error rate $p$")
    ax.set_ylim(0, 1.1)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8)
    ax.set_title("Basin prediction error: generic neural maps and fixed features fail, "
                 "learned nonlinearity recovers")
    fig.savefig(os.path.join(OUT, "fig2_error_bars.png"))
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig 3: sensitivity + learning dynamics
# ---------------------------------------------------------------------------

def fig3():
    sens = np.load(os.path.join(DATA, "fig_sensitivity.npy"))
    deltas, ps = sens[0], sens[1]
    att_p = float(np.load(os.path.join(DATA, "fig_attinit_p.npy"))[0])
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 3.9), constrained_layout=True)
    ax = axes[0]
    ax.semilogx(deltas[1:], ps[1:], "o-", color="#2166ac", label="exact features, perturbed centers")
    ax.semilogx([deltas[1] * 0.5], [ps[0]], "s", color="#2166ac",
                label="$\\delta=0$ (unperturbed)")
    ax.scatter([0.04], [att_p], marker="*", s=160, color="#d6604d", zorder=5,
               label=None)          # fixed-attractor model: center offset
    ax.scatter([1e-4], [0.38], marker="^", s=90, color="#fdae61", zorder=5,
               label=None)          # one-step: stopping residual ~1e-4
    ax.scatter([2e-5], [0.25], marker="P", s=120, color="#1a9850", zorder=5,
               label=None)          # LF-NGRC: final source error ~2e-5
    ax.annotate("attractor init\n($p=0.66$)", xy=(0.04, 0.66),
                xytext=(0.004, 0.74), fontsize=8,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#d6604d"))
    ax.annotate("one-step learning\n($p=0.38$)", xy=(1e-4, 0.38),
                xytext=(4e-4, 0.30), fontsize=8,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#fdae61"))
    ax.annotate("LF-NGRC\n($p=0.25$)", xy=(2e-5, 0.25),
                xytext=(5e-5, 0.17), fontsize=8,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#1a9850"))
    ax.axhline(0.45, ls=":", color="k", lw=1)
    ax.axhline(2 / 3, ls="--", color="k", lw=1)
    ax.set_xlabel("center perturbation $\\delta$")
    ax.set_ylabel("basin error rate $p$")
    ax.set_title("(a) Extreme sensitivity and recovery")
    ax.legend(loc="upper left", fontsize=8)
    ax.set_xlim(1e-5, 0.06)
    ax.set_ylim(0.15, 0.85)
    ax.grid(which="both", ls=":", alpha=0.4)

    ax = axes[1]
    # reconstructed force field vs true force field over the basin region
    centers = np.load(os.path.join(DATA, "fig_J3_centers.npy"))
    heights = np.load(os.path.join(DATA, "fig_J3_heights.npy"))
    g = np.linspace(-1.5, 1.5, 61)
    X, Y = np.meshgrid(g, g)
    rr = np.stack([X.ravel(), Y.ravel()], axis=-1)

    def field(pts, c, h):
        d = c[None, :, :] - pts[:, None, :]
        d3 = (np.sum(d * d, axis=-1, keepdims=True) +
              h[None, :, None] ** 2) ** 1.5
        return np.sum(d / d3, axis=1)

    F_true = field(rr, rp.MAGNETS, np.full(3, 0.2))
    F_learn = field(rr, centers, heights)
    rel = np.linalg.norm(F_learn - F_true, axis=-1) / \
        (np.linalg.norm(F_true, axis=-1) + 1e-6)
    rel = rel.reshape(len(g), len(g))
    im2 = ax.imshow(np.log10(rel), origin="lower",
                    extent=[-1.5, 1.5, -1.5, 1.5], cmap="viridis",
                    vmin=-6, vmax=-1)
    ax.scatter(rp.MAGNETS[:, 0], rp.MAGNETS[:, 1], marker="*", s=150,
               c="white", edgecolors="k", zorder=5, label="true magnets")
    ax.scatter(centers[:, 0], centers[:, 1], marker="o", s=55,
               facecolors="none", edgecolors="white", linewidths=1.5,
               zorder=5, label="learned sources")
    cbar2 = fig.colorbar(im2, ax=ax, fraction=0.046, pad=0.04)
    cbar2.set_label(r"$\log_{10}$ relative force error")
    cbar2.ax.tick_params(labelsize=8)
    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")
    ax.set_title("(b) Reconstructed force field")
    ax.legend(loc="upper right", fontsize=8)
    fig.savefig(os.path.join(OUT, "fig3_sensitivity_learning.png"))
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig 4: Kuramoto basins + gamma learning
# ---------------------------------------------------------------------------

def kuramoto_cmap():
    return ListedColormap(["#2166ac", "#fdae61", "#1a9850"])


def fig4():
    gt = np.load(os.path.join(DATA, "ku_gt101.npy"))
    ex = np.load(os.path.join(DATA, "ku_exact101.npy"))
    lf = np.load(os.path.join(DATA, "ku_lf_pred101.npy"))
    fig, axes = plt.subplots(1, 4, figsize=(15, 3.6), constrained_layout=True)
    cmap = kuramoto_cmap()
    norm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5], cmap.N)
    for ax, img, title in zip(axes[:3], [gt, ex, lf],
                              ["Ground truth", "Exact $\\sin$ nonlinearity",
                               "LF-NGRC (learned $\\gamma$)"]):
        im = ax.imshow(img, origin="lower", extent=[-np.pi, np.pi, -np.pi, np.pi],
                       cmap=cmap, norm=norm)
        ax.set_title(title)
        ax.set_xlabel("$\\alpha_1$")
        ax.set_ylabel("$\\alpha_2$")
    cbar = fig.colorbar(im, ax=axes[:3], fraction=0.025, pad=0.02, ticks=[0, 1, 2])
    cbar.ax.set_yticklabels(["$|q|=0$", "$|q|=1$", "$|q|=2$"])
    cbar.ax.tick_params(labelsize=8)
    ax = axes[3]
    gamma = float(np.load(os.path.join(DATA, "fig_gamma.npy"))[0])
    sw = np.load(os.path.join(DATA, "ku_gamma_sweep.npy"))
    gams, accs = sw[0], sw[1]
    ax.plot(gams, accs, "o-", lw=1.5, color="#1a9850",
            label="basin accuracy")
    ax.axhline(1 / 3, ls="--", color="k", lw=1, label="random guess")
    ax.scatter([gamma], [np.interp(gamma, gams, accs)], marker="*", s=160,
               color="#d6604d", zorder=5, label="learned $\\gamma$")
    ax.set_xlabel(r"coupling scale $\gamma$")
    ax.set_ylabel("basin accuracy")
    ax.set_title("(d) Sensitivity to $\\gamma$")
    ax.legend(loc="lower left", fontsize=8)
    ax.set_ylim(0.3, 1.02)
    fig.suptitle("Kuramoto ring ($n=9$): twisted-state basins")
    fig.savefig(os.path.join(OUT, "fig4_kuramoto.png"))
    plt.show()
    plt.close(fig)
    print("exact acc", np.mean(ex == gt), " LF acc", np.mean(lf == gt))


if __name__ == "__main__":
    fig1()
    fig2()
    fig3()
    fig4()
    print("figures written to", OUT)
