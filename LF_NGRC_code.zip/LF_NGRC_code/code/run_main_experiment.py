"""Main experiment: LF-NGRC vs baselines on magnetic-pendulum basins.

Same-data comparison at dt=0.01, k=3, Ntraj=10, Ntrain=2000, lambda=1e-4:
  * exact nonlinearity (Model III)
  * LF-NGRC point-source dictionary (J=3), attractor initialization
  * LF-NGRC one-step-only ablation (no closed-loop terms)
  * LF-NGRC random-initialization ablation
Also recomputes the paper's Model I (poly) and Model II (RBF) at their own
configurations for reference.
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time, json
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp
from lf_ngrc import PointSourceFeatures, LFNGRC
from run_lfngrc import make_data, train_exact, eval_basins

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_seed(seed, grid, outdir, do_random_init=True):
    t0 = time.time()
    rng = np.random.default_rng(seed)
    trajs, val_traj, S0 = make_data(10, 2000, 0.01, 3, seed)
    vrng = np.random.default_rng(1000 + seed)
    vlist = []
    for _ in range(3):
        v0 = np.hstack([vrng.uniform(-1.5, 1.5, (1, 2)), np.zeros((1, 2))])
        vlist.append(rp.sample_trajectory(v0[0], 0.01, 1200 + 3))
    gt = rp.ground_truth_basins(grid, grid, dt=0.01)
    print(f"[seed {seed}] data+gt {time.time()-t0:.0f}s")

    res = {"seed": seed}

    # exact baseline
    Wex = train_exact(trajs, 3, 0.01, 1e-4)
    Zall = np.concatenate([rp.make_delay_states(S, 3)[:-1] for S in trajs])
    Yall = np.concatenate([S[3:] - S[2:-1] for S in trajs])
    mse_ex = float(np.mean(
        (Yall - rp.exact_features(Zall, 3) @ Wex.T) ** 2))
    pred_ex_map = eval_basins(Wex, lambda Z: rp.exact_features(Z, 3),
                              3, 0.01, grid)
    p_ex, _ = rp.error_rate(pred_ex_map, gt)
    res["exact"] = p_ex
    res["mse_exact"] = mse_ex
    print(f"[seed {seed}] exact p={p_ex:.4f} {time.time()-t0:.0f}s")

    # LF-NGRC closed loop, attractor init
    dic = PointSourceFeatures(3, rng=rng)
    model = LFNGRC(dic, 3, lamb=1e-4, seed=seed)
    hist, W = model.fit(trajs, vlist, rollout_steps=500, a1=1.0, a2=0.1,
                        a3=0.1, iters=1100, verbose=0, roll_min=30,
                        roll_growth=1.01, n_windows=6, two_phase=True,
                        phase1_iters=300, phase1_lr=0.01, phase2_lr=0.05)
    pred_lf_map = eval_basins(W, model.feature_fn_numpy(), 3, 0.01, grid)
    p_lf, _ = rp.error_rate(pred_lf_map, gt)
    res["lf_closed"] = p_lf
    res["centers"] = model.dict_np["centers"].tolist()
    res["heights"] = model.dict_np["heights"].tolist()
    np.save(os.path.join(outdir, f"hist_s{seed}.npy"), hist)
    np.save(os.path.join(outdir, f"W_s{seed}.npy"), W)
    if seed == 0:
        # figure data artifacts (Fig. 1 panels and Fig. 3b learned sources)
        np.save(os.path.join(outdir, "fig_exact101.npy"), pred_ex_map)
        np.save(os.path.join(outdir, "fig_lf101.npy"), pred_lf_map)
        np.save(os.path.join(outdir, "fig_J3_centers.npy"),
                model.dict_np["centers"])
        np.save(os.path.join(outdir, "fig_J3_heights.npy"),
                model.dict_np["heights"])
    print(f"[seed {seed}] LF closed p={p_lf:.4f} {time.time()-t0:.0f}s")

    # LF-NGRC one-step only (no closed-loop terms)
    dic1 = PointSourceFeatures(3, rng=rng)
    model1 = LFNGRC(dic1, 3, lamb=1e-4, seed=seed)
    hist1, W1 = model1.fit(trajs, vlist, rollout_steps=50, a1=0.0, a2=0.0,
                           a3=0.0, iters=300, lr=0.01, verbose=0,
                           roll_min=50, roll_growth=1.0, n_windows=2,
                           two_phase=False)
    p_1, _ = rp.error_rate(
        eval_basins(W1, model1.feature_fn_numpy(), 3, 0.01, grid), gt)
    mse_1 = float(np.mean(
        (Yall - model1.feature_fn_numpy()(Zall) @ W1.T) ** 2))
    res["lf_onestep"] = p_1
    res["mse_lf_onestep"] = mse_1
    res["centers_onestep"] = model1.dict_np["centers"].tolist()
    print(f"[seed {seed}] LF one-step p={p_1:.4f} {time.time()-t0:.0f}s")

    if do_random_init:
        # LF-NGRC closed loop, random init (no attractor knowledge)
        dic2 = PointSourceFeatures(3, rng=rng)
        model2 = LFNGRC(dic2, 3, lamb=1e-4, seed=seed)
        hist2, W2 = model2.fit(trajs, vlist, rollout_steps=500, a1=1.0,
                               a2=0.1, a3=0.1, iters=1100, verbose=0,
                               roll_min=30, roll_growth=1.01, n_windows=6,
                               init_attractors=False, two_phase=True,
                               phase1_iters=300, phase1_lr=0.01,
                               phase2_lr=0.05)
        p_2, _ = rp.error_rate(
            eval_basins(W2, model2.feature_fn_numpy(), 3, 0.01, grid), gt)
        res["lf_randominit"] = p_2
        res["centers_randominit"] = model2.dict_np["centers"].tolist()
        print(f"[seed {seed}] LF random-init p={p_2:.4f} {time.time()-t0:.0f}s")

    with open(os.path.join(outdir, f"res_s{seed}.json"), "w") as f:
        json.dump(res, f, indent=1)
    print(f"[seed {seed}] done {time.time()-t0:.0f}s")
    return res


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3,
                    help="number of random seeds")
    ap.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "outputs"))
    args = ap.parse_args()
    # Experiment outputs go to code/outputs so reruns never overwrite the
    # canonical data/ (figures read from data/).
    outdir = args.out
    os.makedirs(outdir, exist_ok=True)
    grid = np.linspace(-1.5, 1.5, 101)
    all_res = {}
    for seed in range(args.seeds):
        all_res[str(seed)] = run_seed(seed, grid, outdir)
    with open(os.path.join(outdir, "summary.json"), "w") as f:
        json.dump(all_res, f, indent=1)
    print("summary:", {k: {kk: vv for kk, vv in v.items()
                           if not isinstance(vv, (list, dict))}
                       for k, v in all_res.items()})
