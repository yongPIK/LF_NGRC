"""Fine-step exact-nonlinearity baseline (Table 1, last row).

Config: k=3, Delta t = 3.125e-4, N_traj = 100, N_train ~ 2e4 (the trajectory
must cover the full transient: 2000 samples at this dt are only 0.625 time
units, far from converged), lambda = 1e-4, evaluated on the 51x51 grid.
Expected error rate p ~ 0.007 (mean over seeds; Zhang & Cornelius report
~0.014 with lambda = 1). Results are accumulated in
code/outputs/fine_dt_summary.json.

Run:  python fine_dt_baseline.py
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time, argparse, json
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(ntraj=100, ntrain=20000, dt=3.125e-4, k=3, lamb=1e-4,
         grid=51, seed=0, outdir=None):
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    t0 = time.time()
    rng = np.random.default_rng(seed)
    S0 = np.hstack([rng.uniform(-1.5, 1.5, (ntraj, 2)),
                    np.zeros((ntraj, 2))])
    trajs = rp.sample_trajectories(S0, dt, ntrain + k)
    print(f"data ready {time.time()-t0:.0f}s  trajs {trajs.shape}")

    # ridge fit, accumulated per trajectory (keeps memory flat)
    GG = GY = None
    for S in trajs:
        Z = rp.make_delay_states(S, k)[:-1]
        G = rp.exact_features(Z, k)
        Y = S[k:] - S[k - 1 : -1]
        if GG is None:
            m = G.shape[1]
            GG = np.zeros((m, m))
            GY = np.zeros((m, 4))
        GG += G.T @ G
        GY += G.T @ Y
    W = np.linalg.solve(GG + lamb * np.eye(GG.shape[0]), GY).T
    print(f"exact trained {time.time()-t0:.0f}s  W {W.shape}")

    gridv = np.linspace(-1.5, 1.5, grid)
    gt_path = os.path.join(outdir, "gt_dt001.npy")
    if not os.path.exists(gt_path):
        alt = os.path.join(PKG, "data", "gt_dt001.npy")
        if os.path.exists(alt):
            gt_path = alt
    gt = np.load(gt_path) if (grid == 51 and os.path.exists(gt_path)) else \
        rp.ground_truth_basins(gridv, gridv, dt=0.01)
    pred = rp.predict_basins(W, lambda Z: rp.exact_features(Z, k),
                             k, gridv, gridv, dt)
    p, bad = rp.error_rate(pred, gt)
    print(f"fine-dt exact: p = {p:.4f}  ({bad}/{pred.size}) "
          f"({time.time()-t0:.0f}s)")
    np.save(os.path.join(outdir, "fine_dt_pred.npy"), pred)
    summary_path = os.path.join(outdir, "fine_dt_summary.json")
    summary = {}
    if os.path.exists(summary_path):
        with open(summary_path, "r", encoding="utf-8") as f:
            summary = json.load(f)
    key = f"ntraj{ntraj}_ntrain{ntrain}_dt{dt:g}_k{k}_lamb{lamb:g}_grid{grid}_seed{seed}"
    summary[key] = {"ntraj": ntraj, "ntrain": ntrain, "dt": dt, "k": k,
                    "lamb": lamb, "grid": grid, "seed": seed, "p": float(p)}
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=1)
    return float(p)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ntraj", type=int, default=100)
    ap.add_argument("--ntrain", type=int, default=20000)
    ap.add_argument("--dt", type=float, default=3.125e-4)
    ap.add_argument("--k", type=int, default=3)
    ap.add_argument("--lamb", type=float, default=1e-4)
    ap.add_argument("--grid", type=int, default=51)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    main(ntraj=args.ntraj, ntrain=args.ntrain, dt=args.dt, k=args.k,
         lamb=args.lamb, grid=args.grid, seed=args.seed, outdir=args.out)
