"""Reproduce the Catch-22 magnetic-pendulum NGRC baselines.

Follows Zhang & Cornelius (PRResearch 5, 033213, 2023) Methods:
  * trajectories of the real system integrated adaptively with tight
    tolerances (Vern9 in the paper; DOP853 rtol=atol=1e-10 here) and
    sampled every Delta t;
  * NGRC update x_{t+1} = x_t + W g_t, ridge fit;
  * basin = closest magnet after simulating T=100 time units.
"""

import numpy as np
from scipy.integrate import solve_ivp

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from rc_core import (
    MAGNETS, OMEGA0, ALPHA, H, pendulum_rhs, pendulum_force_features,
)


# ---------------------------------------------------------------------------
# Accurate trajectory sampling (mirrors Vern9 + tol 1e-10 in the paper)
# ---------------------------------------------------------------------------

def sample_trajectory(s0, dt, n_samples, rtol=1e-10, atol=1e-10, method="DOP853"):
    """Integrate the pendulum from s0 and return n_samples+1 states spaced dt."""
    t_eval = np.arange(n_samples + 1) * dt
    sol = solve_ivp(
        lambda t, s: pendulum_rhs(s),
        (0.0, t_eval[-1]),
        np.asarray(s0, dtype=float),
        t_eval=t_eval,
        rtol=rtol,
        atol=atol,
        method=method,
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y.T


def sample_trajectories(S0, dt, n_samples, rtol=1e-10, atol=1e-10):
    """Batch version; returns (N, n_samples+1, 4)."""
    out = np.empty((len(S0), n_samples + 1, 4))
    for i, s0 in enumerate(S0):
        out[i] = sample_trajectory(s0, dt, n_samples, rtol, atol)
    return out


# ---------------------------------------------------------------------------
# Feature maps (bias + k*4 linear + nonlinear part), matching the paper
# ---------------------------------------------------------------------------

def make_delay_states(S, k):
    T = len(S)
    n = T - k + 1
    return np.column_stack([S[k - 1 - i : T - i] for i in range(k)])


def exact_features(Z, k, h=H):
    """Model III: 1 bias + 4k linear + 6k pendulum-force features."""
    n = len(Z)
    feats = [np.ones((n, 1)), Z]
    for i in range(k):
        r = Z[:, 4 * i : 4 * i + 2]
        feats.append(pendulum_force_features(r, h=h))
    return np.hstack(feats)


def poly_features(Z, k, dmax):
    """Model I: 1 bias + 4k linear + monomials of total degree 2..dmax."""
    from itertools import combinations_with_replacement

    n, mlin = Z.shape
    feats = [np.ones((n, 1)), Z]
    cols = list(range(mlin))
    for d in range(2, dmax + 1):
        for comb in combinations_with_replacement(cols, d):
            f = np.ones(n)
            for j in comb:
                f = f * Z[:, j]
            feats.append(f[:, None])
    return np.hstack(feats)


def rbf_features_map(Z, k, centers, h=H):
    """Model II: 1 bias + 4k linear + Nc*k RBF features on positions."""
    n = len(Z)
    feats = [np.ones((n, 1)), Z]
    for i in range(k):
        r = Z[:, 4 * i : 4 * i + 2]
        d2 = np.sum((r[:, None, :] - centers[None, :, :]) ** 2, axis=-1) + h * h
        feats.append(d2 ** (-1.5))
    return np.hstack(feats)


# ---------------------------------------------------------------------------
# NGRC training (incremental G^T G, G^T Y accumulation)
# ---------------------------------------------------------------------------

def train_ngrc(trajs, k, feature_fn, lamb, dt):
    """trajs: (Ntraj, L, 4). Returns W (4, m), feature dimension."""
    m = None
    GG = None
    GY = None
    for S in trajs:
        Z = make_delay_states(S, k)[:-1]          # rows t = k-1 .. L-2
        G = feature_fn(Z)
        Y = S[k:] - S[k - 1 : -1]                  # (rows, 4)
        if GG is None:
            m = G.shape[1]
            GG = np.zeros((m, m))
            GY = np.zeros((m, 4))
        GG += G.T @ G
        GY += G.T @ Y
    W = np.linalg.solve(GG + lamb * np.eye(m), GY).T   # (4, m)
    return W


def predict_basins(W, feature_fn, k, grid_x, grid_y, dt, T=100.0,
                   warm_fn=None, batch=4096, div_limit=10.0):
    """Run the trained NGRC from grid starts; return labels {-2,0,1,2}."""
    xx, yy = np.meshgrid(grid_x, grid_y)
    starts = np.stack([xx.ravel(), yy.ravel(), np.zeros_like(xx.ravel()),
                       np.zeros_like(xx.ravel())], axis=-1)
    n = len(starts)
    labels = np.full(n, -1, dtype=int)
    finals = np.full((n, 2), np.nan)
    steps = int(np.ceil(T / dt))
    for b0 in range(0, n, batch):
        b = starts[b0 : b0 + batch]
        nb = len(b)
        if warm_fn is None:
            hist = warmup_true(b, k, dt)
        else:
            hist = warm_fn(b)
        buf = hist.copy()  # buf[:, 0] = newest, buf[:, -1] = oldest
        active = np.ones(nb, dtype=bool)
        for _ in range(steps):
            if not active.any():
                break
            idx = np.where(active)[0]
            sub = buf[idx]
            Z = sub.reshape(len(idx), k * 4)
            G = feature_fn(Z)
            xnew = sub[:, 0, :] + G @ W.T
            buf[idx, 1:] = sub[:, :-1]
            buf[idx, 0] = xnew
            bad = np.any(np.abs(xnew[:, :2]) > div_limit, axis=1)
            if bad.any():
                j = idx[bad]
                labels[b0 + j] = -2
                active[j] = False
        idx = np.where(active)[0]
        finals[b0 + idx] = buf[idx, 0, :2]
    rem = np.where(labels == -1)[0]
    r = finals[rem]
    labels[rem] = np.argmin(np.sum((MAGNETS - r[:, None, :]) ** 2, axis=-1), axis=-1)
    return labels.reshape(len(grid_y), len(grid_x))


def warmup_true(b, k, dt, internal_dt=0.002):
    """k accurate states (t=0..(k-1)dt) from the true system.

    Returns buf with buf[:, 0] = newest state (t=(k-1)dt).
    """
    b = np.asarray(b, dtype=float)
    nb = len(b)
    hist = np.empty((nb, k, 4))
    hist[:, 0, :] = b
    if k > 1:
        n_in = 1 if dt <= internal_dt else int(round(dt / internal_dt))
        h = dt / n_in
        s = b.copy()
        for j in range(k - 1):
            for _ in range(n_in):
                k1 = pendulum_rhs(s)
                k2 = pendulum_rhs(s + 0.5 * h * k1)
                k3 = pendulum_rhs(s + 0.5 * h * k2)
                k4 = pendulum_rhs(s + h * k3)
                s = s + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
            hist[:, j + 1, :] = s
    # newest first
    return hist[:, ::-1].copy()


def ground_truth_basins(grid_x, grid_y, dt=0.01, T=100.0, batch=4096):
    """Basins of the real system, same rule (closest magnet after T)."""
    xx, yy = np.meshgrid(grid_x, grid_y)
    starts = np.stack([xx.ravel(), yy.ravel(), np.zeros_like(xx.ravel()),
                       np.zeros_like(xx.ravel())], axis=-1)
    n = len(starts)
    labels = np.full(n, -1, dtype=int)
    steps = int(np.ceil(T / dt))
    internal_dt = 0.002
    n_in = 1 if dt <= internal_dt else int(round(dt / internal_dt))
    h = dt / n_in
    for b0 in range(0, n, batch):
        b = starts[b0 : b0 + batch].copy()
        for _ in range(steps):
            for _ in range(n_in):
                k1 = pendulum_rhs(b)
                k2 = pendulum_rhs(b + 0.5 * h * k1)
                k3 = pendulum_rhs(b + 0.5 * h * k2)
                k4 = pendulum_rhs(b + h * k3)
                b = b + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        r = b[:, :2]
        labels[b0 : b0 + batch] = np.argmin(
            np.sum((MAGNETS - r[:, None, :]) ** 2, axis=-1), axis=-1
        )
    return labels.reshape(len(grid_y), len(grid_x))


def settle_attractors(S0, dt=0.01, T=100.0, batch=4096, tol=0.1):
    """Final positions of trajectories started at S0, run to T (data collection).

    Returns the distinct cluster centers (observable settling points).
    """
    S0 = np.atleast_2d(np.asarray(S0, dtype=float))
    n = len(S0)
    finals = np.empty((n, 2))
    steps = int(np.ceil(T / dt))
    internal_dt = 0.002
    n_in = 1 if dt <= internal_dt else int(round(dt / internal_dt))
    h = dt / n_in
    for b0 in range(0, n, batch):
        b = S0[b0 : b0 + batch].copy()
        for _ in range(steps):
            for _ in range(n_in):
                k1 = pendulum_rhs(b)
                k2 = pendulum_rhs(b + 0.5 * h * k1)
                k3 = pendulum_rhs(b + 0.5 * h * k2)
                k4 = pendulum_rhs(b + h * k3)
                b = b + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        finals[b0 : b0 + batch] = b[:, :2]
    centers = []
    for p in finals:
        if not centers or np.min(np.linalg.norm(np.array(centers) - p, axis=1)) > tol:
            centers.append(p)
    return np.array(centers)


def error_rate(pred, truth):
    m = pred != truth
    return m.mean(), m.sum()


if __name__ == "__main__":
    import time

    t0 = time.time()
    # ---- headline exact-nonlinearity config from the paper ----
    k, dt, lamb, ntraj, ntrain = 4, 0.01, 1e-4, 1, 1000
    rng = np.random.default_rng(0)
    S0 = rng.uniform(-1.5, 1.5, (ntraj, 2))
    S0 = np.hstack([S0, np.zeros((ntraj, 2))])
    trajs = sample_trajectories(S0, dt, ntrain + k)
    W = train_ngrc(trajs, k, lambda Z: exact_features(Z, k), lamb, dt)
    print(f"trained exact k={k} dt={dt} lamb={lamb} Ntraj={ntraj} "
          f"Ntrain={ntrain} in {time.time()-t0:.1f}s, W shape {W.shape}")
    grid = np.linspace(-1.5, 1.5, 101)
    pred = predict_basins(W, lambda Z: exact_features(Z, k), k, grid, grid, dt)
    gt = ground_truth_basins(grid, grid, dt)
    p, bad = error_rate(pred, gt)
    print(f"error rate p = {p:.4f}  ({bad}/{gt.size})")
