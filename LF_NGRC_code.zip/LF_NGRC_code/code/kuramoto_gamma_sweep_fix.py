"""Regenerate the Kuramoto gamma-sweep with the fixed basin evaluator.

The saved ku_gamma_sweep.npy (peak 98% at gamma=1) is inconsistent with the
exact-model accuracy (99.0%) and with the paper text. This script reruns the
sweep with the fixed _eval_slice so that the gamma=1 point matches the exact
model, then saves the corrected sweep to data/ku_gamma_sweep.npy.

Run:  python kuramoto_gamma_sweep_fix.py
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import sys, time, json
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kuramoto_lf as ku

CODE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(CODE)
DATA = os.path.join(PKG, "data")

N, DT, K, LAMB = 9, 0.01, 2, 1e-5
N_TRAJ, N_TRAIN = 200, 3000
GRID = 101
GAMS = [0.5, 0.7, 0.8, 0.9, 0.95, 1.0, 1.05, 1.1, 1.2, 1.5]


def main():
    t0 = time.time()
    rng = np.random.default_rng(0)
    S0 = rng.uniform(0.0, 2.0 * np.pi, (N_TRAJ, N))
    trajs = np.stack([ku.integrate_kuramoto(th, DT, tmax=(N_TRAIN + K) * DT,
                                            return_full=True)[:, 0, :]
                      for th in S0])
    th0 = 2.0 * np.pi * 2 * np.arange(N) / N
    P1 = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1], dtype=float)
    P2 = np.array([0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=float)
    print(f"data ready {time.time()-t0:.0f}s", flush=True)

    ku_gt, _, _ = ku.ground_truth_kuramoto(th0, P1, P2, DT, grid=GRID)
    accs = []
    for g in GAMS:
        Wg = ku._train_ngrc_ridge(
            trajs, K, LAMB, lambda Z, g_=g: ku._sine_features(Z, K, g_))
        pg = ku._eval_slice(Wg, lambda Z, g_=g: ku._sine_features(Z, K, g_),
                            K, N, th0, P1, P2, DT, grid=GRID)
        accs.append(float(np.mean(pg == ku_gt)))
        print(f"gamma={g:.3f} acc={accs[-1]:.4f} "
              f"({time.time()-t0:.0f}s)", flush=True)
    np.save(os.path.join(DATA, "ku_gamma_sweep.npy"),
            np.stack([np.array(GAMS), np.array(accs)]))
    summary = {"gamma": GAMS, "acc": accs,
               "acc_at_gamma1": accs[GAMS.index(1.0)]}
    with open(os.path.join(DATA, "ku_gamma_sweep_fix_summary.json"),
              "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=1)
    print("saved ku_gamma_sweep.npy; acc(1.0)=%.4f" % accs[GAMS.index(1.0)],
          flush=True)


if __name__ == "__main__":
    main()
