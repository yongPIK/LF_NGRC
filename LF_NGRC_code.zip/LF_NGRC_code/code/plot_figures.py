"""Generate publication figures for the LF-NGRC paper."""

import os, sys, json
import numpy as np
import matplotlib
if os.environ.get("LF_HEADLESS") == "1":
    matplotlib.use("Agg")          # headless mode: save only, no display
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp

# Resolve paths relative to the package (works from any CWD)
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
DATA = os.environ.get("LF_DATA", os.path.join(PKG, "data"))
OUT = os.environ.get(
    "LF_FIGOUT",
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 "outputs", "figures"))
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "figure.dpi": 150,
})


# ---------------------------------------------------------------------------
# Fig 1: magnetic pendulum basins
# ---------------------------------------------------------------------------

def pendulum_cmap():
    return ListedColormap(["black", "#2166ac", "#fdae61", "#1a9850"])


def plot_basin(ax, img, title, vmax=2):
    cmap = pendulum_cmap()
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5, 2.5], cmap.N)
    img2 = np.where(img == -2, -1, img)
    im = ax.imshow(img2, origin="lower", extent=[-1.5, 1.5, -1.5, 1.5],
                   cmap=cmap, norm=norm)
    ax.set_title(title)
    ax.set_xlabel("$x_0$")
    ax.set_ylabel("$y_0$")
    ax.set_xticks([-1.5, 0, 1.5])
    ax.set_yticks([-1.5, 0, 1.5])
    return im


def fig1():
    gt = np.load(os.path.join(DATA, "gt101.npy"))
    exact = np.load(os.path.join(DATA, "fig_exact101.npy"))
    lf = np.load(os.path.join(DATA, "fig_lf101.npy"))
    poly = np.load(os.path.join(DATA, "poly_pred.npy"))
    rbf = np.load(os.path.join(DATA, "rbf_pred.npy"))
    fig, axes = plt.subplots(1, 5, figsize=(15, 3.2), constrained_layout=True)
    plot_basin(axes[0], gt, "Ground truth")
    plot_basin(axes[1], poly, "Polynomial")
    plot_basin(axes[2], rbf, "Random RBF")
    plot_basin(axes[3], exact, "Exact nonlinearity")
    im = plot_basin(axes[4], lf, "LF-NGRC (learned)")
    cbar = fig.colorbar(im, ax=axes, fraction=0.025, pad=0.02, ticks=[0, 1, 2])
    cbar.ax.set_yticklabels(["magnet 1", "magnet 2", "magnet 3"])
    cbar.ax.tick_params(labelsize=8)
    fig.suptitle("Magnetic pendulum basins ($\\Delta t=0.01$, $k=3$, $N_\\mathrm{traj}=10$)")
    fig.savefig(os.path.join(OUT, "fig1_pendulum_basins.png"))
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig 2: error-rate bar chart
# ---------------------------------------------------------------------------

def fig2():
    summary = json.load(open(os.path.join(DATA, "summary.json")))
    models = ["Polynomial\n(NGRC-I)", "Random RBF\n(NGRC-II)",
              "MLP map\none-step", "MLP map\nclosed-loop",
              "Exact\nnonlin.", "LF-NGRC\none-step",
              "LF-NGRC\nrandom init", "LF-NGRC\nclosed loop"]
    arr_exact = np.array([summary[s]["exact"] for s in summary])
    arr_1s = np.array([summary[s]["lf_onestep"] for s in summary])
    arr_ri = np.array([summary[s]["lf_randominit"] for s in summary])
    arr_cl = np.array([summary[s]["lf_closed"] for s in summary])
    # Model I/II: 20-seed stats (SI sweep) with fallback to the single values
    pr_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "outputs", "sweeps", "poly_rbf_seed_stats.json")
    pr = {}
    if os.path.exists(pr_path):
        pr = json.load(open(pr_path))
    poly_mean = pr.get("mean_poly", 0.9889)
    poly_std = pr.get("std_poly", 0.0)
    rbf_mean = pr.get("mean_rbf", 0.5855)
    rbf_std = pr.get("std_rbf", 0.0)
    # MLP: 5-seed stats (SI sweep) with fallback to the single values
    mlp = {}
    mlp_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "outputs", "sweeps",
                            "mlp_multi_seed_summary.json")
    if not os.path.exists(mlp_path):
        alt = os.path.join(DATA, "mlp_results.json")
        if os.path.exists(alt):
            mlp = json.load(open(alt))
        p_mlp1 = mlp.get("p_onestep", 0.8062)
        p_mlp2 = mlp.get("p_closedloop", 0.7283)
        s_mlp1 = s_mlp2 = 0.0
    else:
        mlp = json.load(open(mlp_path))
        p_mlp1 = mlp.get("p_onestep_mean", 0.8556)
        p_mlp2 = mlp.get("p_closedloop_mean", 0.8951)
        s_mlp1 = mlp.get("p_onestep_std", 0.0)
        s_mlp2 = mlp.get("p_closedloop_std", 0.0)
    data = [[poly_mean, poly_std], [rbf_mean, rbf_std],
            [p_mlp1, s_mlp1], [p_mlp2, s_mlp2],
            arr_exact, arr_1s, arr_ri, arr_cl]
    means = [np.mean(d) if isinstance(d, np.ndarray) else d[0]
             for d in data]
    errs = [np.std(d) if isinstance(d, np.ndarray) else d[1]
            for d in data]
    fig, ax = plt.subplots(figsize=(10.0, 3.8))
    fig.subplots_adjust(left=0.07, right=0.78, top=0.86, bottom=0.17)
    bars = ax.bar(range(len(models)), means, yerr=errs, capsize=4,
                  color=["#8c8c8c", "#8c8c8c", "#b2182b", "#d6604d",
                         "#2166ac", "#fdae61", "#d6604d", "#1a9850"])
    ax.axhline(2 / 3, ls="--", color="k", lw=1, label="random guess")
    ax.axhline(0.45, ls=":", color="k", lw=1, label="useful threshold ($p=0.45$)")
    for b, m in zip(bars, means):
        ax.text(b.get_x() + b.get_width() / 2, m + 0.02, f"{m:.2f}",
                ha="center", fontsize=9)
    ax.set_xticks(range(len(models)))
    ax.set_xticklabels(models)
    ax.set_ylabel("basin error rate $p$")
    ax.set_ylim(0, 1.1)
    ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), fontsize=8)
    ax.set_title("Basin prediction error: generic neural maps and fixed features fail, "
                 "learned nonlinearity recovers")
    fig.savefig(os.path.join(OUT, "fig2_error_bars.png"))
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig 3: sensitivity + learning dynamics
# ---------------------------------------------------------------------------

def fig3():
    sens = np.load(os.path.join(DATA, "fig_sensitivity.npy"))
    deltas, ps = sens[0], sens[1]
    att_p = float(np.load(os.path.join(DATA, "fig_attinit_p.npy"))[0])
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 3.9), constrained_layout=True)
    ax = axes[0]
    ax.semilogx(deltas[1:], ps[1:], "o-", color="#2166ac", label="exact features, perturbed centers")
    ax.semilogx([deltas[1] * 0.5], [ps[0]], "s", color="#2166ac",
                label="$\\delta=0$ (unperturbed)")
    ax.scatter([0.04], [att_p], marker="*", s=160, color="#d6604d", zorder=5,
               label=None)          # fixed-attractor model: center offset
    ax.scatter([1e-4], [0.38], marker="^", s=90, color="#fdae61", zorder=5,
               label=None)          # one-step: stopping residual ~1e-4
    ax.scatter([2e-5], [0.25], marker="P", s=120, color="#1a9850", zorder=5,
               label=None)          # LF-NGRC: final source error ~2e-5
    ax.annotate("attractor init\n($p=0.66$)", xy=(0.04, 0.66),
                xytext=(0.004, 0.74), fontsize=8,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#d6604d"))
    ax.annotate("one-step learning\n($p=0.38$)", xy=(1e-4, 0.38),
                xytext=(4e-4, 0.30), fontsize=8,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#fdae61"))
    ax.annotate("LF-NGRC\n($p=0.25$)", xy=(2e-5, 0.25),
                xytext=(5e-5, 0.17), fontsize=8,
                arrowprops=dict(arrowstyle="->", lw=0.8, color="#1a9850"))
    ax.axhline(0.45, ls=":", color="k", lw=1)
    ax.axhline(2 / 3, ls="--", color="k", lw=1)
    ax.set_xlabel("center perturbation $\\delta$")
    ax.set_ylabel("basin error rate $p$")
    ax.set_title("(a) Extreme sensitivity and recovery")
    ax.legend(loc="upper left", fontsize=8)
    ax.set_xlim(1e-5, 0.06)
    ax.set_ylim(0.15, 0.85)
    ax.grid(which="both", ls=":", alpha=0.4)

    ax = axes[1]
    # reconstructed force field vs true force field over the basin region
    centers = np.load(os.path.join(DATA, "fig_J3_centers.npy"))
    heights = np.load(os.path.join(DATA, "fig_J3_heights.npy"))
    g = np.linspace(-1.5, 1.5, 61)
    X, Y = np.meshgrid(g, g)
    rr = np.stack([X.ravel(), Y.ravel()], axis=-1)

    def field(pts, c, h):
        d = c[None, :, :] - pts[:, None, :]
        d3 = (np.sum(d * d, axis=-1, keepdims=True) +
              h[None, :, None] ** 2) ** 1.5
        return np.sum(d / d3, axis=1)

    F_true = field(rr, rp.MAGNETS, np.full(3, 0.2))
    F_learn = field(rr, centers, heights)
    rel = np.linalg.norm(F_learn - F_true, axis=-1) / \
        (np.linalg.norm(F_true, axis=-1) + 1e-6)
    rel = rel.reshape(len(g), len(g))
    im2 = ax.imshow(np.log10(rel), origin="lower",
                    extent=[-1.5, 1.5, -1.5, 1.5], cmap="viridis",
                    vmin=-6, vmax=-1)
    ax.scatter(rp.MAGNETS[:, 0], rp.MAGNETS[:, 1], marker="*", s=150,
               c="white", edgecolors="k", zorder=5, label="true magnets")
    ax.scatter(centers[:, 0], centers[:, 1], marker="o", s=55,
               facecolors="none", edgecolors="white", linewidths=1.5,
               zorder=5, label="learned sources")
    cbar2 = fig.colorbar(im2, ax=ax, fraction=0.046, pad=0.04)
    cbar2.set_label(r"$\log_{10}$ relative force error")
    cbar2.ax.tick_params(labelsize=8)
    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")
    ax.set_title("(b) Reconstructed force field")
    ax.legend(loc="upper right", fontsize=8)
    fig.savefig(os.path.join(OUT, "fig3_sensitivity_learning.png"))
    plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Fig 4: Kuramoto basins + gamma learning
# ---------------------------------------------------------------------------

def kuramoto_cmap():
    return ListedColormap(["#2166ac", "#fdae61", "#1a9850"])


def fig4():
    gt = np.load(os.path.join(DATA, "ku_gt101.npy"))
    ex = np.load(os.path.join(DATA, "ku_exact101.npy"))
    lf = np.load(os.path.join(DATA, "ku_lf_pred101.npy"))
    fig, axes = plt.subplots(1, 4, figsize=(15, 3.6), constrained_layout=True)
    cmap = kuramoto_cmap()
    norm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5], cmap.N)
    for ax, img, title in zip(axes[:3], [gt, ex, lf],
                              ["Ground truth", "Exact $\\sin$ nonlinearity",
                               "LF-NGRC (learned $\\gamma$)"]):
        im = ax.imshow(img, origin="lower", extent=[-np.pi, np.pi, -np.pi, np.pi],
                       cmap=cmap, norm=norm)
        ax.set_title(title)
        ax.set_xlabel("$\\alpha_1$")
        ax.set_ylabel("$\\alpha_2$")
    cbar = fig.colorbar(im, ax=axes[:3], fraction=0.025, pad=0.02, ticks=[0, 1, 2])
    cbar.ax.set_yticklabels(["$|q|=0$", "$|q|=1$", "$|q|=2$"])
    cbar.ax.tick_params(labelsize=8)
    ax = axes[3]
    gamma = float(np.load(os.path.join(DATA, "fig_gamma.npy"))[0])
    sw = np.load(os.path.join(DATA, "ku_gamma_sweep.npy"))
    gams, accs = sw[0], sw[1]
    ax.plot(gams, accs, "o-", lw=1.5, color="#1a9850",
            label="basin accuracy")
    ax.axhline(1 / 3, ls="--", color="k", lw=1, label="random guess")
    ax.scatter([gamma], [np.interp(gamma, gams, accs)], marker="*", s=160,
               color="#d6604d", zorder=5, label="learned $\\gamma$")
    ax.set_xlabel(r"coupling scale $\gamma$")
    ax.set_ylabel("basin accuracy")
    ax.set_title("(d) Sensitivity to $\\gamma$")
    ax.legend(loc="lower left", fontsize=8)
    ax.set_ylim(0.3, 1.02)
    fig.suptitle("Kuramoto ring ($n=9$): twisted-state basins")
    fig.savefig(os.path.join(OUT, "fig4_kuramoto.png"))
    plt.show()
    plt.close(fig)
    print("exact acc", np.mean(ex == gt), " LF acc", np.mean(lf == gt))



# ---------------------------------------------------------------------------
# Merged figures: Fig.3 (J=4), Fig.5 (spectral ablation), Fig.6 (parameters)
# Data are read from JSON bundles in code/outputs/sweeps/.
# ---------------------------------------------------------------------------
import argparse
import glob as _glob

SWEEP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "outputs", "sweeps")


def _bundle(name):
    with open(os.path.join(SWEEP_DIR, name + ".json"), "r",
              encoding="utf-8") as f:
        return json.load(f)


def _series(bundle, keys, xvals, models):
    """bundle[key] = list of per-seed dicts -> {model: (xs, means, sds)}."""
    acc = {m: {} for m in models}
    for i, key in enumerate(keys):
        for res in bundle.get(key, []):
            for m in models:
                v = res.get(m)
                if v is None and m == "lf_closed":
                    v = res.get("p")
                if v is not None:
                    acc[m].setdefault(xvals[i], []).append(v)
    out = {}
    for m in models:
        if not acc[m]:
            continue
        xs = sorted(acc[m])
        out[m] = (xs,
                  [float(np.mean(acc[m][x])) for x in xs],
                  [float(np.std(acc[m][x], ddof=1)) for x in xs])
    return out


# ---------------------------------------------------------------- Fig. 3 ----
def figJ4():
    pred = np.load(os.path.join(DATA, "lf_J4_pred.npy"))
    centers = np.load(os.path.join(DATA, "lf_J4_centers.npy"))
    heights = np.load(os.path.join(DATA, "lf_J4_heights.npy"))
    jsweep = _bundle("j")

    fig, axes = plt.subplots(1, 3, figsize=(14.0, 4.2),
                             constrained_layout=True)
    ax = axes[0]
    cmap = ListedColormap(["black", "#2166ac", "#fdae61", "#1a9850"])
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5, 2.5], cmap.N)
    img = np.where(pred == -2, -1, pred)
    ax.imshow(img, origin="lower", extent=[-1.5, 1.5, -1.5, 1.5],
              cmap=cmap, norm=norm)
    ax.set_title("(a) LF-NGRC basins, $J=4$")
    ax.set_xlabel("$x_0$")
    ax.set_ylabel("$y_0$")

    ax = axes[1]
    mags = rp.MAGNETS
    ax.scatter(mags[:, 0], mags[:, 1], marker="*", s=260, c="#000000",
               label="true magnets ($h=0.2$)", zorder=5)
    ax.scatter(centers[:, 0], centers[:, 1], s=140, facecolors="none",
               edgecolors="#d6604d", linewidths=1.8,
               label="learned sources", zorder=4)
    hs = ", ".join(f"{h:.3f}" for h in heights)
    ax.text(-1.55, 1.05, f"learned $h^*$:\n{hs}\ntrue $h = 0.200$",
            fontsize=8, va="top",
            bbox=dict(facecolor="white", alpha=0.85, edgecolor="0.5"))
    ax.annotate("redundant pair", xy=(-0.31, -0.52), xytext=(-0.95, -1.32),
                fontsize=9, arrowprops=dict(arrowstyle="->", lw=1))
    ax.set_xlim(-1.6, 1.6)
    ax.set_ylim(-1.6, 1.6)
    ax.set_aspect("equal")
    ax.set_title("(b) Learned sources vs magnets")
    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")
    ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), fontsize=8)
    ax.text(0.35, 1.32, "basin error $p = 0.237$",
            fontsize=9, bbox=dict(facecolor="white", alpha=0.8))

    ax = axes[2]
    keys = ["J2", "J3", "J4", "J5"]
    ser = _series(jsweep, keys, [2, 3, 4, 5], ["lf_closed"])
    xs, means, sds = ser["lf_closed"]
    ax.errorbar(xs, means, yerr=sds, color="#d62728", marker="s", ls="-",
                lw=1.5, ms=5, capsize=3, label="LF-NGRC (closed loop)")
    ax.axhline(2 / 3, color="0.45", ls=":", lw=1.2)
    ax.axhline(0.45, color="0.45", ls="--", lw=1.2)
    ax.text(5, 2 / 3 + 0.02, "Random guess", ha="right", fontsize=8,
            color="0.3")
    ax.text(5, 0.45 + 0.02, "Useful prediction", ha="right", fontsize=8,
            color="0.3")
    ax.set_xticks(xs)
    ax.set_xlabel("Dictionary size $J$")
    ax.set_ylabel("Error rate $p$")
    ax.set_ylim(0.0, 0.85)
    ax.grid(alpha=0.25, lw=0.5)
    ax.legend(fontsize=8, frameon=False, loc="upper right")
    fig.savefig(os.path.join(OUT, "fig3_J4_overcomplete.png"),
                dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("saved fig3_J4_overcomplete.png", {j: round(m, 4)
                                             for j, m in zip(xs, means)})


# ---------------------------------------------------------------- Fig. 5 ----
def fig_spec():
    b = _bundle("d3_ablation")
    defaults, ablated = [], []
    for N in (10, 100):
        for res in b[f"default_ntr{N}"]:
            defaults.append((N, res["seed"], res["p"], res["rho"]))
        for res in b[f"ablated_ntr{N}"]:
            ablated.append((N, res["seed"], res["p"], max(res["rho"])))
    refs = [("exact", b["ref_exact"]["p"], max(b["ref_exact"]["rho"])),
            ("onestep", b["ref_onestep"]["p"], max(b["ref_onestep"]["rho"]))]

    fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.6))
    ax = axes[0]
    for g, N in enumerate((10, 100)):
        pd_ = {r[1]: r[2] for r in defaults if r[0] == N}
        pa_ = {r[1]: r[2] for r in ablated if r[0] == N}
        seeds = sorted(set(pd_) & set(pa_))
        for i, s in enumerate(seeds):
            jit = (i - (len(seeds) - 1) / 2) * 0.012
            ax.scatter([g + jit - 0.18], [pd_[s]], s=22, color="#2166ac",
                       zorder=3, edgecolor="w", lw=0.3)
            ax.scatter([g + jit + 0.18], [pa_[s]], s=22, marker="^",
                       color="#d6604d", zorder=3, edgecolor="w", lw=0.3)
    ax.axhline(2 / 3, ls="--", color="k", lw=0.9)
    ax.axhline(0.45, ls=":", color="k", lw=0.9)
    ax.text(1.5, 2 / 3 + 0.012, "random guess", fontsize=8, ha="center")
    ax.text(1.5, 0.45 + 0.012, "useful threshold", fontsize=8, ha="center")
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["$N_{\\mathrm{traj}}=10$",
                        "$N_{\\mathrm{traj}}=100$"])
    ax.set_xlim(-0.85, 1.85)
    ax.set_ylim(0.15, 0.70)
    ax.set_ylabel("basin error rate $p$")
    ax.set_title("(a) Spectral-penalty ablation (20 seeds)", fontsize=10)
    ax.scatter([], [], s=22, color="#2166ac", edgecolor="w", lw=0.3,
               label=r"LF closed, $\beta_3=0.1$")
    ax.scatter([], [], s=22, marker="^", color="#d6604d", edgecolor="w",
               lw=0.3, label=r"LF closed, $\beta_3=0$")
    ax.legend(loc="upper left", fontsize=8)

    ax = axes[1]
    for r in defaults:
        ax.scatter([r[3]], [r[2]], s=22, color="#2166ac", zorder=3,
                   edgecolor="w", lw=0.3)
    for r in ablated:
        ax.scatter([r[3]], [r[2]], s=22, marker="^", color="#d6604d",
                   zorder=3, edgecolor="w", lw=0.3)
    for mode, p, rho in refs:
        mk = "o" if mode == "exact" else "s"
        ec = "#333333" if mode == "exact" else "#888888"
        ax.scatter([rho], [p], s=70, marker=mk, facecolors="none",
                   edgecolors=ec, lw=1.6, zorder=4)
    ax.axvline(1.0, color="k", ls="--", lw=1.0)
    ax.axvspan(1.0, 1.9, color="#d6604d", alpha=0.06)
    ax.text(1.42, 0.655, r"$\rho>1$: locally unstable", fontsize=8,
            color="#d6604d")
    ax.set_xlabel(r"spectral radius $\rho$ at observed fixed points")
    ax.set_ylabel("basin error rate $p$")
    ax.set_xlim(0.95, 1.9)
    ax.set_ylim(0.20, 0.70)
    ax.set_title("(b) Failure coincides with $\\rho>1$ (20 seeds)",
                 fontsize=10)
    ax.scatter([], [], s=22, color="#2166ac", edgecolor="w", lw=0.3,
               label=r"LF closed, $\beta_3=0.1$")
    ax.scatter([], [], s=22, marker="^", color="#d6604d", edgecolor="w",
               lw=0.3, label=r"LF closed, $\beta_3=0$")
    ax.scatter([], [], s=70, marker="o", facecolors="none",
               edgecolors="#333333", lw=1.6,
               label="exact nonlinearity (ref)")
    ax.scatter([], [], s=70, marker="s", facecolors="none",
               edgecolors="#888888", lw=1.6,
               label="LF-NGRC one-step (ref)")
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(os.path.join(OUT, "fig5_spectral_ablation.png"), dpi=150)
    plt.close(fig)
    print("saved fig5_spectral_ablation.png")


# ---------------------------------------------------------------- Fig. 6 ----
_LS = {
    "exact": dict(color="#1f77b4", marker="o", ls="-",
                  label="Exact nonlinearity"),
    "lf_closed": dict(color="#d62728", marker="s", ls="-",
                      label="LF-NGRC (closed loop)"),
    "lf_onestep": dict(color="#ff7f0e", marker="^", ls="--",
                       label="LF-NGRC (one-step only)"),
    "rbf": dict(color="#2ca02c", marker="D", ls=":",
                label="Random RBF"),
}


def fig_param():
    ntraj = _bundle("ntraj")
    verify = _bundle("verify20")
    # fresh-seed overrides used in the paper
    for res in ntraj.get("ntr100", []):
        res.pop("lf_closed", None)
    for res in verify["ntr100"]:
        ntraj["ntr100"].append({"seed": res["seed"],
                                "lf_closed": res["p_lf_closed"]})
    dt = _bundle("dt")
    for res in dt.get("dt0.005", []):
        res.pop("lf_closed", None)
    for res in verify["dt5"]:
        dt["dt0.005"].append({"seed": res["seed"],
                              "lf_closed": res["p_lf_closed"]})
    lamb = _bundle("lamb")

    fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.8),
                             constrained_layout=True)
    specs = [
        (axes[0], ntraj, ["ntr1", "ntr3", "ntr10", "ntr30", "ntr100"],
         [1, 3, 10, 30, 100],
         ["exact", "lf_closed", "lf_onestep", "rbf"],
         "Training trajectories $N_\\mathrm{traj}$",
         "(a) $N_\\mathrm{traj}$"),
        (axes[1], lamb, ["l1e-06", "l0.0001", "l0.01", "l0.1"],
         [1e-6, 1e-4, 1e-2, 0.1],
         ["exact", "lf_closed", "lf_onestep"],
         "Ridge regularization $\\lambda$", "(b) $\\lambda$"),
        (axes[2], dt, ["dt0.00125", "dt0.005", "dt0.01", "dt0.02", "dt0.04"],
         [1.25e-3, 5e-3, 1e-2, 2e-2, 4e-2],
         ["exact", "lf_closed", "lf_onestep"],
         "Sampling interval $\\Delta t$", "(c) $\\Delta t$"),
    ]
    handles, labels = [], []
    for ax, bundle, keys, xvals, models, xlabel, title in specs:
        ser = _series(bundle, keys, xvals, models)
        for m, (xs, means, sds) in ser.items():
            h = ax.errorbar(xs, means, yerr=sds, capsize=3, lw=1.4,
                            ms=4.5, **_LS[m])
            if not handles:
                handles.append(h)
                labels.append(_LS[m]["label"])
        ax.axhline(2 / 3, color="0.45", ls=":", lw=1.1)
        ax.axhline(0.45, color="0.45", ls="--", lw=1.1)
        ax.text(ax.get_xlim()[1], 2 / 3 + 0.015, "Random guess",
                ha="right", va="bottom", fontsize=7, color="0.3")
        ax.text(ax.get_xlim()[1], 0.45 + 0.015, "Useful prediction",
                ha="right", va="bottom", fontsize=7, color="0.3")
        ax.set_xscale("log")
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Error rate $p$")
        ax.set_ylim(0.0, 1.05)
        ax.set_title(title, fontsize=10)
        ax.grid(alpha=0.25, lw=0.5)
    fig.legend(handles, labels, loc="lower center", ncol=4, fontsize=8,
               frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("Dependence on algorithmic parameters "
                 "(mean $\\pm$ SD over 20 seeds, $51\\times51$ grid)",
                 fontsize=10)
    fig.savefig(os.path.join(OUT, "fig6_parameter_dependence.png"),
                dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("saved fig6_parameter_dependence.png")


# ------------------------------------------------------------- dispatcher ----
def pack_bundles():
    """Re-pack per-seed json files (from a full rerun) into the bundles."""
    def _load_dir(prefix):
        out = {}
        for path in _glob.glob(os.path.join(SWEEP_DIR, prefix + "_*_s*.json")):
            stem = os.path.basename(path)[:-5]
            key = stem.rsplit("_s", 1)[0][len(prefix) + 1:]
            with open(path, "r", encoding="utf-8") as f:
                out.setdefault(key, []).append(json.load(f))
        for k in out:
            out[k].sort(key=lambda r: r.get("seed", 0))
        return out

    for name in ("j", "ntraj", "lamb", "dt"):
        with open(os.path.join(SWEEP_DIR, name + ".json"), "w",
                  encoding="utf-8") as f:
            json.dump(_load_dir(name), f)
    verify = {}
    for prefix, key in (("ntr100", "ntr100"), ("dt5", "dt5")):
        verify[key] = []
        for path in _glob.glob(os.path.join(SWEEP_DIR, "verify20",
                                            prefix + "_s*.json")):
            with open(path, "r", encoding="utf-8") as f:
                verify[key].append(json.load(f))
        verify[key].sort(key=lambda r: r["seed"])
    with open(os.path.join(SWEEP_DIR, "verify20.json"), "w",
              encoding="utf-8") as f:
        json.dump(verify, f)
    d3 = {}
    d3dir = os.path.join(SWEEP_DIR, "d3_ablation")
    for tag, model, N in (("default_ntr10", "default", 10),
                          ("default_ntr100", "default", 100),
                          ("ablated_ntr10", "ablated", 10),
                          ("ablated_ntr100", "ablated", 100)):
        d3[tag] = []
        for s in range(20):
            p = os.path.join(d3dir, f"{model}_ntr{N}_s{s}.json")
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    d3[tag].append(json.load(f))
    for tag, stem in (("ref_exact", "exact_ntr10_s0"),
                      ("ref_onestep", "onestep_ntr10_s0")):
        with open(os.path.join(d3dir, stem + ".json"), "r",
                  encoding="utf-8") as f:
            d3[tag] = json.load(f)
    with open(os.path.join(SWEEP_DIR, "d3_ablation.json"), "w",
              encoding="utf-8") as f:
        json.dump(d3, f)
    print("bundles written to", SWEEP_DIR)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("which", nargs="*", default=["all"],
                    help="all | fig1 .. fig7 | pack")
    args = ap.parse_args()
    wanted = args.which
    if "pack" in wanted:
        pack_bundles()
        return
    if "all" in wanted:
        wanted = ["fig1", "fig2", "fig3", "fig4", "fig5", "fig6", "fig7"]
    table = {"fig1": fig1, "fig2": fig2, "fig3": figJ4, "fig4": fig3,
             "fig5": fig_spec, "fig6": fig_param, "fig7": fig4}
    for w in wanted:
        if w not in table:
            raise SystemExit(f"unknown figure '{w}'")
        table[w]()


if __name__ == "__main__":
    main()
