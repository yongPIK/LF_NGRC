"""Figure 6: dependence on algorithmic parameters (merged three-panel figure).

Panels: (a) error rate p vs number of training trajectories N_traj;
(b) p vs ridge regularization lambda; (c) p vs sampling interval Delta t.
Mean +/- sample SD over 20 seeds; 51x51 grid.

Run:  python plot_sweeps.py
"""

import os
import json
import glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

CODE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(CODE)
SWEEP_DIR = os.path.join(CODE, "outputs", "sweeps")
VERIFY_DIR = os.path.join(SWEEP_DIR, "verify20")
FIG_DIR = os.path.join(PKG, "figures")

P_RANDOM, P_USEFUL = 2.0 / 3.0, 0.45

LINESTYLE = {
    "exact": dict(color="#1f77b4", marker="o", ls="-",
                  label="Exact nonlinearity"),
    "lf_closed": dict(color="#d62728", marker="s", ls="-",
                      label="LF-NGRC (closed loop)"),
    "lf_onestep": dict(color="#ff7f0e", marker="^", ls="--",
                       label="LF-NGRC (one-step only)"),
    "rbf": dict(color="#2ca02c", marker="D", ls=":",
                label="Random RBF"),
}


def load_sweep(name):
    """Return dict[(key, seed)] -> result dict."""
    out = {}
    for path in glob.glob(os.path.join(SWEEP_DIR, f"{name}_*.json")):
        stem = os.path.basename(path)[len(name) + 1:-5]
        seed = int(stem.rsplit("_s", 1)[1])
        key = stem.rsplit("_s", 1)[0]
        with open(path, "r", encoding="utf-8") as f:
            out[(key, seed)] = json.load(f)
    return out


def apply_overrides(data, overrides):
    """Replace selected (key, model) values with fresh-seed runs."""
    for key, models in overrides.items():
        for model, prefix in models.items():
            for (k, s) in list(data.keys()):
                if k == key:
                    data[(k, s)].pop(model, None)
            for path in glob.glob(os.path.join(VERIFY_DIR,
                                               f"{prefix}_s*.json")):
                stem = os.path.basename(path)[:-5]
                seed = int(stem.rsplit("_s", 1)[1])
                with open(path, "r", encoding="utf-8") as f:
                    res = json.load(f)
                data.setdefault((key, seed), {})[model] = res["p_lf_closed"]
    return data


def series_of(keys, xvals, models, data):
    """Return {model: (xs, means, sds)} from per-seed results."""
    acc = {m: {} for m in models}
    for i, key in enumerate(keys):
        for (k, seed), res in data.items():
            if k != key:
                continue
            for m in models:
                v = res.get(m)
                if v is None and m == "lf_closed":
                    v = res.get("p")            # legacy field in j-sweep
                if v is not None:
                    acc[m].setdefault(xvals[i], []).append(v)
    out = {}
    for m in models:
        if not acc[m]:
            continue
        xs = sorted(acc[m])
        means = [float(np.mean(acc[m][x])) for x in xs]
        sds = [float(np.std(acc[m][x], ddof=1)) for x in xs]
        out[m] = (xs, means, sds)
    return out


def draw(ax, ser, xlabel, logx, title):
    handles = []
    for m, (xs, means, sds) in ser.items():
        h = ax.errorbar(xs, means, yerr=sds, capsize=3, lw=1.4, ms=4.5,
                        **LINESTYLE[m])
        handles.append(h)
    ax.axhline(P_RANDOM, color="0.45", ls=":", lw=1.1)
    ax.axhline(P_USEFUL, color="0.45", ls="--", lw=1.1)
    ax.text(ax.get_xlim()[1], P_RANDOM + 0.015, "Random guess",
            ha="right", va="bottom", fontsize=7, color="0.3")
    ax.text(ax.get_xlim()[1], P_USEFUL + 0.015, "Useful prediction",
            ha="right", va="bottom", fontsize=7, color="0.3")
    if logx:
        ax.set_xscale("log")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Error rate $p$")
    ax.set_ylim(0.0, 1.05)
    ax.set_title(title, fontsize=10)
    ax.grid(alpha=0.25, lw=0.5)
    return handles


def main():
    d_ntraj = apply_overrides(load_sweep("ntraj"),
                              {"ntr100": {"lf_closed": "ntr100"}})
    d_dt = apply_overrides(load_sweep("dt"),
                           {"dt0.005": {"lf_closed": "dt5"}})
    lamb = load_sweep("lamb")

    fig, axes = plt.subplots(1, 3, figsize=(13.5, 3.8),
                             constrained_layout=True)

    ser_a = series_of(["ntr1", "ntr3", "ntr10", "ntr30", "ntr100"],
                      [1, 3, 10, 30, 100],
                      ["exact", "lf_closed", "lf_onestep", "rbf"], d_ntraj)
    handles = draw(axes[0], ser_a, "Training trajectories $N_\\mathrm{traj}$",
                   True, "(a) $N_\\mathrm{traj}$")

    ser_b = series_of(["l1e-06", "l0.0001", "l0.01", "l0.1"],
                      [1e-6, 1e-4, 1e-2, 0.1],
                      ["exact", "lf_closed", "lf_onestep"], lamb)
    draw(axes[1], ser_b, "Ridge regularization $\\lambda$",
         True, "(b) $\\lambda$")

    ser_c = series_of(["dt0.00125", "dt0.005", "dt0.01", "dt0.02", "dt0.04"],
                      [1.25e-3, 5e-3, 1e-2, 2e-2, 4e-2],
                      ["exact", "lf_closed", "lf_onestep"], d_dt)
    draw(axes[2], ser_c, "Sampling interval $\\Delta t$",
         True, "(c) $\\Delta t$")

    labels = [LINESTYLE[m]["label"] for m in ser_a]
    fig.legend(handles, labels, loc="lower center", ncol=4,
               fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("Dependence on algorithmic parameters "
                 "(mean $\\pm$ SD over 20 seeds, $51\\times51$ grid)",
                 fontsize=10)

    os.makedirs(FIG_DIR, exist_ok=True)
    out = os.path.join(FIG_DIR, "fig6_parameter_dependence.png")
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)
    for name, ser in [("N_traj", ser_a), ("lambda", ser_b), ("dt", ser_c)]:
        print(" ", name, {m: [round(v, 4) for v in ser[m][1]]
                          for m in ser})


if __name__ == "__main__":
    main()
