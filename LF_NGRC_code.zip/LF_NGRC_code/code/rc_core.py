"""Core simulators and NGRC machinery for the catch-22 project."""

from __future__ import annotations

import numpy as np


# ----------------------------------------------------------------------------
# Magnetic pendulum (Zhang & Cornelius, PRResearch 2023)
# ----------------------------------------------------------------------------

MAGNETS = np.array(
    [
        [1.0 / np.sqrt(3.0), 0.0],
        [-1.0 / (2.0 * np.sqrt(3.0)), -0.5],
        [-1.0 / (2.0 * np.sqrt(3.0)), 0.5],
    ]
)
OMEGA0 = 0.5
ALPHA = 0.2
H = 0.2


def pendulum_force(x, y, magnets=MAGNETS, h=H):
    """Magnetic force on the bob at (x, y). Returns (fx, fy)."""
    dx = magnets[:, 0] - x  # (3,)
    dy = magnets[:, 1] - y
    d3 = (dx * dx + dy * dy + h * h) ** 1.5
    fx = np.sum(dx / d3)
    fy = np.sum(dy / d3)
    return fx, fy


def pendulum_rhs(state, magnets=MAGNETS, omega0=OMEGA0, alpha=ALPHA, h=H):
    """state: (..., 4) as [x, y, vx, vy]."""
    x = state[..., 0]
    y = state[..., 1]
    vx = state[..., 2]
    vy = state[..., 3]
    dx = magnets[:, 0] - x[..., None]
    dy = magnets[:, 1] - y[..., None]
    d3 = (dx * dx + dy * dy + h * h) ** 1.5
    fx = np.sum(dx / d3, axis=-1)
    fy = np.sum(dy / d3, axis=-1)
    ddx = -omega0 * omega0 * x - alpha * vx + fx
    ddy = -omega0 * omega0 * y - alpha * vy + fy
    return np.stack([vx, vy, ddx, ddy], axis=-1)


def pendulum_rk4_step(s, dt, magnets=MAGNETS, omega0=OMEGA0, alpha=ALPHA, h=H):
    k1 = pendulum_rhs(s, magnets, omega0, alpha, h)
    k2 = pendulum_rhs(s + 0.5 * dt * k1, magnets, omega0, alpha, h)
    k3 = pendulum_rhs(s + 0.5 * dt * k2, magnets, omega0, alpha, h)
    k4 = pendulum_rhs(s + dt * k3, magnets, omega0, alpha, h)
    return s + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)



def pendulum_force_features(r, magnets=MAGNETS, h=H):
    """Exact force features at positions r (..., 2) -> (..., 6)."""
    x = r[..., 0]
    y = r[..., 1]
    dx = magnets[:, 0] - x[..., None]
    dy = magnets[:, 1] - y[..., None]
    d3 = (dx * dx + dy * dy + h * h) ** 1.5
    return np.concatenate([dx / d3, dy / d3], axis=-1)
