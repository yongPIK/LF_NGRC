"""PINN-style comparison: generic gradient-trained neural maps on the pendulum.

A reviewer's question: would a PINN / generic gradient-descent neural network,
with the same data (and optionally the same weak prior), beat LF-NGRC?

Two baselines are trained on the *same* data as LF-NGRC:
  A) MLP map, one-step (teacher-forced) regression  -> "PINN data term only"
  B) MLP map, one-step + closed-loop roll-out loss  -> generic NN with the
     same closed-loop objective as LF-NGRC (BPTT through the map)
Then basins are predicted by autonomous iteration of the learned map.
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time
import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp
from run_lfngrc import make_data

# Resolve data/output paths relative to the package (works from any CWD)
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
DATA_DIR = os.environ.get("LF_DATA", os.path.join(PKG, "data"))
OUT_DIR = os.environ.get(
    "LF_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "outputs"))
os.makedirs(OUT_DIR, exist_ok=True)


def make_delay_states(S, k):
    T = len(S)
    n = T - k + 1
    return np.column_stack([S[k - 1 - i : T - i] for i in range(k)])


class MLPMap(nn.Module):
    """State-delay -> increment map, x_{t+1} = x_t + net(Z_t)."""

    def __init__(self, d_in, d_out, hidden=128, layers=2):
        super().__init__()
        blocks = []
        for _ in range(layers):
            blocks.append(nn.Linear(d_in, hidden))
            blocks.append(nn.SiLU())
            d_in = hidden
        blocks.append(nn.Linear(hidden, d_out))
        self.net = nn.Sequential(*blocks)

    def forward(self, Z):
        return self.net(Z)


def build_data(seed=0, ntraj=10, ntrain=2000, k=3, dt=0.01, n_val=3):
    trajs, val_traj, S0 = make_data(ntraj, ntrain, dt, k, seed)
    vrng = np.random.default_rng(1000 + seed)
    vlist = []
    for _ in range(n_val):
        v0 = np.hstack([vrng.uniform(-1.5, 1.5, (1, 2)), np.zeros((1, 2))])
        vlist.append(rp.sample_trajectory(v0[0], dt, 1200 + k))
    Z = torch.tensor(np.concatenate(
        [make_delay_states(S, k)[:-1] for S in trajs]), dtype=torch.float32)
    Y = torch.tensor(np.concatenate(
        [S[k:] - S[k - 1 : -1] for S in trajs]), dtype=torch.float32)
    return trajs, vlist, Z, Y


def train_mlp_one_step(Z, Y, seed=0, epochs=3000, lr=1e-3, batch=1024,
                       val_frac=0.1, verbose=500):
    torch.manual_seed(seed)
    n = len(Z)
    perm = torch.randperm(n)
    nv = int(val_frac * n)
    Zv, Yv = Z[perm[:nv]], Y[perm[:nv]]
    Zt, Yt = Z[perm[nv:]], Y[perm[nv:]]
    # standardize
    zm, zs = Zt.mean(0), Zt.std(0) + 1e-8
    ym, ys = Yt.mean(0), Yt.std(0) + 1e-8
    model = MLPMap(Z.shape[1], Y.shape[1])
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    best = (1e9, None)
    best_r2 = 0.0
    yvar = torch.var(Yv).item()
    for it in range(epochs):
        model.train()
        idx = torch.randperm(len(Zt))[:batch]
        pred = model((Zt[idx] - zm) / zs)
        loss = torch.mean(((pred * ys + ym) - Yt[idx]) ** 2)
        opt.zero_grad()
        loss.backward()
        opt.step()
        if it % verbose == 0:
            model.eval()
            with torch.no_grad():
                pv = model((Zv - zm) / zs) * ys + ym
                lv = torch.mean((pv - Yv) ** 2).item()
            if lv < best[0]:
                best = (lv, {k2: v.detach().clone() for k2, v in model.state_dict().items()})
                best_r2 = 1.0 - lv / yvar if yvar > 0 else 0.0
            print(f"it {it}: train {loss.item():.3e} val {lv:.3e}", flush=True)
    model.eval()
    if best[1] is not None:
        model.load_state_dict(best[1])
    return model, (zm, zs, ym, ys), best[0], best_r2


def train_mlp_closed_loop(Z, Y, vlist, k=3, seed=0, epochs=400, lr=1e-3,
                          roll=40, n_windows=6, a1=1.0, clip=0.5,
                          verbose=50):
    """Generic MLP trained with the same closed-loop objective as LF-NGRC."""
    torch.manual_seed(seed)
    zm, zs = Z.mean(0), Z.std(0) + 1e-8
    ym, ys = Y.mean(0), Y.std(0) + 1e-8
    yvar = torch.mean(Y ** 2).item()
    model = MLPMap(Z.shape[1], Y.shape[1])
    Vbufs = [torch.tensor(make_delay_states(Vv, k), dtype=torch.float32)
             for Vv in vlist]
    Vs = [torch.tensor(Vv, dtype=torch.float32) for Vv in vlist]
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    n = Z.shape[1] // k
    for it in range(epochs):
        model.train()
        idx = torch.randperm(len(Z))[:4096]
        pred = model((Z[idx] - zm) / zs) * ys + ym
        L_step = torch.mean((pred - Y[idx]) ** 2) / yvar
        errs = []
        for Vbuf, V in zip(Vbufs, Vs):
            starts = list(range(0, Vbuf.shape[0] - roll,
                                max(1, (Vbuf.shape[0] - roll) // n_windows)))[:n_windows]
            for s in starts:
                buf = Vbuf[s : s + 1].clone()
                for t in range(roll):
                    xnew = buf[:, 0:4] + model((buf - zm) / zs) * ys + ym
                    e = xnew[0] - V[k + s + t]
                    errs.append(clip * torch.tanh(e / clip))
                    if t + 1 < roll:
                        buf[:, 4:] = buf[:, :-4].clone()
                        buf[:, 0:4] = xnew
        L_roll = torch.mean(torch.stack(errs) ** 2) / yvar
        loss = L_step + a1 * L_roll
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
        opt.step()
        if it % verbose == 0:
            print(f"it {it}: L {loss.item():.4f} step {L_step.item():.4f} "
                  f"roll {L_roll.item():.4f}", flush=True)
    model.eval()
    return model, (zm, zs, ym, ys)


def predict_basins_map(model, stats, k, grid_x, grid_y, dt, T=100.0,
                       batch=4096, div_limit=10.0):
    zm, zs, ym, ys = stats
    xx, yy = np.meshgrid(grid_x, grid_y)
    starts = np.stack([xx.ravel(), yy.ravel(), np.zeros_like(xx.ravel()),
                       np.zeros_like(xx.ravel())], axis=-1)
    n = len(starts)
    labels = np.full(n, -1, dtype=int)
    finals = np.full((n, 2), np.nan)
    steps = int(np.ceil(T / dt))
    for b0 in range(0, n, batch):
        b = starts[b0 : b0 + batch]
        nb = len(b)
        hist = rp.warmup_true(b, k, dt)
        buf = hist.copy()
        active = np.ones(nb, dtype=bool)
        for _ in range(steps):
            if not active.any():
                break
            idx = np.where(active)[0]
            sub = buf[idx]
            Zt = torch.tensor(sub.reshape(len(idx), k * 4), dtype=torch.float32)
            with torch.no_grad():
                inc = (model((Zt - zm) / zs) * ys + ym).numpy()
            xnew = sub[:, 0, :] + inc
            buf[idx, 1:] = sub[:, :-1]
            buf[idx, 0] = xnew
            bad = np.any(np.abs(xnew[:, :2]) > div_limit, axis=1)
            if bad.any():
                j = idx[bad]
                labels[b0 + j] = -2
                active[j] = False
        idx = np.where(active)[0]
        finals[b0 + idx] = buf[idx, 0, :2]
    rem = np.where(labels == -1)[0]
    r = finals[rem]
    labels[rem] = np.argmin(np.sum((rp.MAGNETS - r[:, None, :]) ** 2, axis=-1),
                            axis=-1)
    return labels.reshape(len(grid_y), len(grid_x))


if __name__ == "__main__":
    seed = 0
    k = 3
    dt = 0.01
    t0 = time.time()
    trajs, vlist, Z, Y = build_data(seed=seed)
    print(f"data ready {time.time()-t0:.0f}s  Z {tuple(Z.shape)}")

    # A) one-step MLP
    m1, s1, mse1, r2_1 = train_mlp_one_step(Z, Y, seed=seed, epochs=2000)
    torch.save(m1.state_dict(), os.path.join(OUT_DIR, "mlp_onestep.pt"))
    grid = np.linspace(-1.5, 1.5, 101)
    pred1 = predict_basins_map(m1, s1, k, grid, grid, dt)
    np.save(os.path.join(OUT_DIR, "mlp_onestep_pred.npy"), pred1)
    gt_path = os.path.join(DATA_DIR, "gt101.npy")
    if os.path.exists(gt_path):
        gt = np.load(gt_path)
    else:
        gt = rp.ground_truth_basins(grid, grid, dt=dt)
        os.makedirs(DATA_DIR, exist_ok=True)
        np.save(gt_path, gt)
    p1, _ = rp.error_rate(pred1, gt)
    frac1 = float(np.mean(pred1 == -2))
    print(f"MLP one-step: p = {p1:.4f}  unique {np.unique(pred1, return_counts=True)} "
          f"| MSE {mse1:.3e} R2 {r2_1:.3f} frac_div {frac1:.3f} "
          f"({time.time()-t0:.0f}s)", flush=True)

    # B) closed-loop MLP
    m2, s2 = train_mlp_closed_loop(Z, Y, vlist, k=k, seed=seed, epochs=400)
    torch.save(m2.state_dict(), os.path.join(OUT_DIR, "mlp_closedloop.pt"))
    pred2 = predict_basins_map(m2, s2, k, grid, grid, dt)
    np.save(os.path.join(OUT_DIR, "mlp_closedloop_pred.npy"), pred2)
    p2, _ = rp.error_rate(pred2, gt)
    frac2 = float(np.mean(pred2 == -2))
    print(f"MLP closed-loop: p = {p2:.4f}  unique {np.unique(pred2, return_counts=True)} "
          f"| frac_div {frac2:.3f} ({time.time()-t0:.0f}s)", flush=True)

    # persist the numbers used in Table 3 / Section 4.5
    import json
    res = {
        "p_onestep": float(p1), "mse_onestep": float(mse1),
        "r2_onestep": float(r2_1), "frac_div_onestep": frac1,
        "p_closedloop": float(p2), "frac_div_closedloop": frac2,
    }
    with open(os.path.join(OUT_DIR, "mlp_results.json"), "w") as f:
        json.dump(res, f, indent=1)
    print("saved", os.path.join(OUT_DIR, "mlp_results.json"), res)
