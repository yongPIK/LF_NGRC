"""Compute the spectral-penalty ablation (D3) data, 20 seeds.

Two subcommands:
  1) fit    : train the LF closed-loop model with a chosen spectral weight
              beta3 (default 0.0 = ablation) and store p / kappa / rho.
  2) refit  : for the default beta3=0.1 runs, recompute kappa/rho from the
              archived centers/heights of outputs/sweeps/ntraj_ntr*.json
              (no retraining; the readout W(theta) is the ridge solution).

Examples:
  python spectral_ablation_compute.py fit --ntr 10 --seeds 0 1 --a3 0.0
  python spectral_ablation_compute.py refit --ntr 10 100 --seeds 0 19

All results are written to code/outputs/sweeps/d3_ablation/.
"""

import os
import sys
import time
import json
import argparse

os.environ["OMP_NUM_THREADS"] = "2"
os.environ["MKL_NUM_THREADS"] = "2"
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

import numpy as np
import torch

torch.set_num_threads(2)

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import repro_catch22 as rp  # noqa: E402
from lf_ngrc import PointSourceFeatures, LFNGRC, detect_attractors  # noqa
from run_lfngrc import make_data, eval_basins  # noqa: E402
import sweep_pendulum as sp  # noqa: E402

OUT = os.path.join(HERE, "outputs", "sweeps", "d3_ablation")
SWEEPS = os.path.join(HERE, "outputs", "sweeps")
K, DT, LAMB0 = 3, 0.01, 1e-4
GRID = 51


def feat(Z, centers, heights, k=K):
    n = len(Z)
    parts = [np.ones((n, 1)), Z]
    for i in range(k):
        r = Z[:, 4 * i:4 * i + 2]
        d = centers[None, :, :] - r[:, None, :]
        h2 = heights[None, :, None] ** 2
        d3 = (np.sum(d * d, axis=-1, keepdims=True) + h2) ** 1.5
        parts.append((d / d3).reshape(n, 2 * len(centers)))
    return np.hstack(parts)


def rho_spec(W, fn, att2):
    rhos = []
    for a in att2:
        a4 = np.array([a[0], a[1], 0.0, 0.0])

        def H(xt):
            return fn(np.hstack([xt, a4, a4])[None, :]).ravel()

        m = fn(np.zeros((1, 12))).shape[1]
        dg = np.zeros((m, 4))
        for i in range(4):
            e = np.zeros(4)
            e[i] = 1e-6
            dg[:, i] = (H(a4 + e) - H(a4 - e)) / 2e-6
        J = np.eye(4) + W @ dg
        rhos.append(float(np.max(np.abs(np.linalg.eigvals(J)))))
    return rhos


def p_of(W, fn, k, dt):
    pred = eval_basins(W, fn, k, dt, np.linspace(-1.5, 1.5, GRID))
    gt = np.load(os.path.join(PKG, "data", "gt_dt001.npy"))
    p, _ = rp.error_rate(pred, gt)
    return float(p)


def fit_one(ntr, seed, a3, lamb=LAMB0):
    os.makedirs(OUT, exist_ok=True)
    tag = ("ablated" if a3 == 0.0 else "default")
    path = os.path.join(OUT, f"{tag}_ntr{ntr}_s{seed}.json")
    t0 = time.time()
    trajs, _, _ = make_data(ntr, 2000, DT, K, seed)
    vlist = sp.build_val(seed, dt=DT, n_val=3, n_steps=1200)
    rng = np.random.default_rng(seed)
    dic = PointSourceFeatures(3, rng=rng)
    model = LFNGRC(dic, K, lamb=lamb, seed=seed)
    _, W = model.fit(trajs, vlist, rollout_steps=500, a1=1.0, a2=0.1,
                     a3=a3, iters=1100, verbose=0, roll_min=30,
                     roll_growth=1.01, n_windows=6, two_phase=True,
                     phase1_iters=300, phase1_lr=0.01, phase2_lr=0.05)
    fn = model.feature_fn_numpy()
    res = {"p": p_of(W, fn, K, DT), "kappa": float(np.linalg.cond(W)),
           "rho": rho_spec(W, fn, detect_attractors(trajs, K)),
           "centers": model.dict_np["centers"].tolist(),
           "heights": model.dict_np["heights"].tolist(),
           "wall_s": round(time.time() - t0, 1)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1)
    print("saved", path, f"p={res['p']:.4f}", flush=True)


def refit_defaults(ntrs, seeds):
    os.makedirs(OUT, exist_ok=True)
    for ntr in ntrs:
        for s in range(seeds[0], seeds[1] + 1):
            path = os.path.join(OUT, f"default_ntr{ntr}_s{s}.json")
            if os.path.exists(path):
                print("skip", os.path.basename(path), flush=True)
                continue
            t0 = time.time()
            arc = json.load(open(os.path.join(
                SWEEPS, f"ntraj_ntr{ntr}_s{s}.json"), encoding="utf-8"))
            c = np.array(arc["centers"])
            if ntr == 10:
                resm = json.load(open(os.path.join(
                    PKG, "data", f"res_s{s}.json"), encoding="utf-8"))
                h = np.array(resm["heights"])
            else:
                h = np.full(3, 0.2)
            trajs, _, _ = make_data(ntr, 2000, DT, K, s)
            Ztr = np.concatenate(
                [rp.make_delay_states(S, K)[:-1] for S in trajs])
            Ytr = np.concatenate([S[K:] - S[K - 1:-1] for S in trajs])
            fn = lambda Z: feat(Z, c, h)  # noqa: E731
            G = fn(Ztr)
            W = np.linalg.solve(G.T @ G + LAMB0 * np.eye(G.shape[1]),
                                (G.T @ Ytr)).T
            att = detect_attractors(trajs, K)
            res = {"p": arc["lf_closed"],
                   "kappa": float(np.linalg.cond(W)),
                   "rho": max(rho_spec(W, fn, att)),
                   "wall_s": round(time.time() - t0, 1)}
            with open(path, "w", encoding="utf-8") as f:
                json.dump(res, f, indent=1)
            print("saved", os.path.basename(path),
                  f"p={res['p']:.4f} rho={res['rho']:.4f}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("fit")
    p1.add_argument("--ntr", type=int, nargs="+", required=True)
    p1.add_argument("--seeds", type=int, nargs="+", required=True)
    p1.add_argument("--a3", type=float, default=0.0)
    p2 = sub.add_parser("refit")
    p2.add_argument("--ntr", type=int, nargs="+", default=[10, 100])
    p2.add_argument("--seeds", type=int, nargs=2, default=[0, 19])
    args = ap.parse_args()
    if args.cmd == "fit":
        for n in args.ntr:
            for s in args.seeds:
                fit_one(n, s, args.a3)
    else:
        refit_defaults(args.ntr, args.seeds)


if __name__ == "__main__":
    main()
