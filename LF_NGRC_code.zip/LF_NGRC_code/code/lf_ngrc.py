"""Learnable-feature NGRC (LF-NGRC) for the Catch-22 problem.

Core idea: instead of fixing the readout nonlinearity (polynomial / random RBF /
exact), parameterize it by a small dictionary and learn its parameters with a
*closed-loop* objective:

    L(theta) = L_step + a1*L_rollout + a2*L_fixedpoint + a3*L_spectral

where W(theta) is the analytic ridge solution, L_rollout is the multi-step
autonomous roll-out error on a held-out trajectory, L_fixedpoint penalizes
drift of the learned map at attractors observed in the data, and L_spectral
penalizes Jacobian spectral radius > 1 at those attractors.
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix

import numpy as np
import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# Parameterized feature dictionaries
# ---------------------------------------------------------------------------

class PointSourceFeatures(nn.Module):
    """Vector point-source dictionary: f_j(r) = (c_j - r) / (|c_j-r|^2 + h_j^2)^(3/2).

    One vector feature per source per delay. Exact for the magnetic pendulum
    when J = number of magnets and centers/heights match the true ones.
    """

    def __init__(self, J, init_centers=None, init_h=None, h_min=0.02, rng=None):
        super().__init__()
        if init_centers is None:
            init_centers = (rng or np.random.default_rng(0)).uniform(
                -1.0, 1.0, (J, 2))
        self.J = J
        self.h_min = h_min
        self.centers = nn.Parameter(torch.tensor(init_centers, dtype=torch.float64))
        if init_h is None:
            init_h = np.full(J, 0.25)
        self.logh = nn.Parameter(torch.log(torch.tensor(init_h, dtype=torch.float64)))

    @property
    def heights(self):
        return torch.exp(self.logh) + self.h_min

    def force_features(self, r):
        """r: (N, 2) -> (N, 2*J) with columns grouped by source (x then y)."""
        d = self.centers[None, :, :] - r[:, None, :]          # (N, J, 2)
        h2 = self.heights[None, :, None] ** 2
        d3 = (torch.sum(d * d, dim=-1, keepdim=True) + h2) ** 1.5
        return (d / d3).reshape(r.shape[0], 2 * self.J)

    def features(self, Z, k):
        """Z: (N, k*4) delay states -> full feature matrix (N, m)."""
        n = Z.shape[0]
        parts = [torch.ones((n, 1), dtype=Z.dtype, device=Z.device), Z]
        for i in range(k):
            r = Z[:, 4 * i : 4 * i + 2]
            parts.append(self.force_features(r))
        return torch.cat(parts, dim=1)

    def jacobian_newest(self, x, k):
        """Jacobian of the map's feature part w.r.t. the newest state block
        evaluated at a fixed point (all delays equal x). Returns (m, 4)."""
        m = 1 + 4 * k + 2 * self.J * k
        Jg = torch.zeros((m, 4), dtype=x.dtype, device=x.device)
        # linear part: derivative of Z block w.r.t. x_t = identity on first 4 cols
        Jg[1 : 1 + 4, :] = torch.eye(4, dtype=x.dtype, device=x.device)
        # nonlinear part for delay i=0 (newest)
        r = x[:2]
        d = self.centers - r[None, :]                          # (J, 2)
        h2 = self.heights[:, None] ** 2
        d2 = torch.sum(d * d, dim=1, keepdim=True) + h2
        d3 = d2 ** 1.5
        # d/dr [(c - r)/D^3]: (c-r)_a / D^3 derivative w.r.t. r_b
        # = -delta_ab / D^3 - 3 (c-r)_a (c-r)_b / D^5
        base = 1 + 4 * k
        for j in range(self.J):
            gvec = torch.zeros((2, 2), dtype=x.dtype, device=x.device)
            for a in range(2):
                for b in range(2):
                    # dF_a/dr_b = -delta_ab/D^3 + 3 d_a d_b / D^5
                    gvec[a, b] = -((a == b)) / d3[j, 0] + 3 * d[j, a] * d[j, b] / d3[j, 0] ** (5 / 3)
            Jg[base + 2 * j : base + 2 * j + 2, :2] = gvec
        return Jg


class RBFDictionaryFeatures(nn.Module):
    """Scalar RBF dictionary: f_j(r) = 1 / (|c_j-r|^2 + h_j^2)^(3/2), learnable c, h."""

    def __init__(self, J, init_centers=None, init_h=None, h_min=0.02, rng=None):
        super().__init__()
        if init_centers is None:
            init_centers = (rng or np.random.default_rng(0)).uniform(
                -1.5, 1.5, (J, 2))
        self.J = J
        self.h_min = h_min
        self.centers = nn.Parameter(torch.tensor(init_centers, dtype=torch.float64))
        if init_h is None:
            init_h = np.full(J, 0.3)
        self.logh = nn.Parameter(torch.log(torch.tensor(init_h, dtype=torch.float64)))

    @property
    def heights(self):
        return torch.exp(self.logh) + self.h_min

    def rbf_features(self, r):
        d2 = torch.sum((r[:, None, :] - self.centers[None, :, :]) ** 2, dim=-1)
        return (d2 + self.heights[None, :] ** 2) ** (-1.5)

    def features(self, Z, k):
        n = Z.shape[0]
        parts = [torch.ones((n, 1), dtype=Z.dtype, device=Z.device), Z]
        for i in range(k):
            parts.append(self.rbf_features(Z[:, 4 * i : 4 * i + 2]))
        return torch.cat(parts, dim=1)

    def jacobian_newest(self, x, k):
        m = 1 + 4 * k + self.J * k
        Jg = torch.zeros((m, 4), dtype=x.dtype, device=x.device)
        Jg[1 : 1 + 4, :] = torch.eye(4, dtype=x.dtype, device=x.device)
        r = x[:2]
        d = r[None, :] - self.centers                              # (J, 2)
        d2 = torch.sum(d * d, dim=1) + self.heights ** 2
        d5 = d2 ** 2.5
        base = 1 + 4 * k
        for j in range(self.J):
            Jg[base + j, :2] = -3 * d[j] / d5[j]
        return Jg


# ---------------------------------------------------------------------------
# LF-NGRC training
# ---------------------------------------------------------------------------

def ridge_weights(features, Y, lamb):
    """W(theta) = Y G^T (G G^T + lamb I)^-1 ; returns (4, m)."""
    G = features
    m = G.shape[1]
    GG = G.T @ G
    GY = G.T @ Y
    return torch.linalg.solve(GG + lamb * torch.eye(m, dtype=G.dtype, device=G.device), GY).T


def detect_attractors(trajs, k):
    """Attractor positions from the tails of training trajectories."""
    pts = []
    for S in trajs:
        tail = S[-25:]
        pts.append(np.mean(tail[:, :2], axis=0))
    pts = np.array(pts)
    # cluster by distance
    centers = []
    for p in pts:
        if not centers or np.min(np.linalg.norm(np.array(centers) - p, axis=1)) > 0.1:
            centers.append(p)
    return np.array(centers)


class LFNGRC:
    def __init__(self, dictionary, k, lamb=1e-4, seed=0):
        self.dictionary = dictionary
        self.k = k
        self.lamb = lamb
        self.W = None
        self.seed = seed

    def fit(self, trajs, val_traj, rollout_steps=300, a1=1.0, a2=0.1, a3=0.1,
            iters=400, lr=0.03, rho_target=0.99, verbose=10, rng=None,
            clip_scale=0.5, roll_min=10, roll_growth=1.01, grad_clip=10.0,
            n_windows=8, init_attractors=True, two_phase=True,
            phase1_iters=300, phase1_lr=0.01, phase2_lr=0.05,
            attractor_pts=None, callback=None):
        """Optimize dictionary parameters with the closed-loop objective."""
        dev = next(self.dictionary.parameters()).device
        k = self.k
        dtype = torch.float64

        att_np = detect_attractors(trajs, k) if attractor_pts is None \
            else np.asarray(attractor_pts, dtype=float)
        if init_attractors and len(att_np) > 0:
            # initialize centers at the observable settling points
            with torch.no_grad():
                J = self.dictionary.J
                c = self.dictionary.centers
                use = min(J, len(att_np))
                c[:use] = torch.tensor(att_np[:use], dtype=dtype, device=dev)
                if J > use:
                    c[use:] = torch.tensor(att_np[: J - use],
                                           dtype=dtype, device=dev)
                self.dictionary.logh.data.fill_(np.log(max(0.2, self.dictionary.h_min)))

        # training data (fixed)
        Zs, Ys = [], []
        for S in trajs:
            Z = torch.tensor(make_delay(S, k)[:-1], dtype=dtype, device=dev)
            Y = torch.tensor(S[k:] - S[k - 1 : -1], dtype=dtype, device=dev)
            Zs.append(Z)
            Ys.append(Y)
        Z = torch.cat(Zs, dim=0)
        Y = torch.cat(Ys, dim=0)
        yvar = torch.mean(Y * Y).item()

        # validation trajectory (or trajectories) for rollout
        if isinstance(val_traj, (list, tuple)) and not isinstance(val_traj, np.ndarray):
            val_list = list(val_traj)
        else:
            val_list = [np.asarray(val_traj)]
        Vbufs = [torch.tensor(make_delay(Vv, k), dtype=dtype, device=dev)
                 for Vv in val_list]
        Vs = [torch.tensor(Vv, dtype=dtype, device=dev) for Vv in val_list]
        att = torch.tensor(detect_attractors(trajs, k), dtype=dtype, device=dev)

        phase2_iters = max(1, iters - phase1_iters)
        opt = torch.optim.Adam(self.dictionary.parameters(),
                               lr=phase1_lr if (two_phase and phase1_iters) else lr)
        sched = None
        if not (two_phase and phase1_iters):
            sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                opt, T_max=iters, eta_min=max(lr / 1000.0, 1e-6))
        hist = []
        roll_now = roll_min
        win_starts = []
        for Vbuf in Vbufs:
            if Vbuf.shape[0] > rollout_steps:
                starts = list(range(0, Vbuf.shape[0] - rollout_steps,
                                    max(1, (Vbuf.shape[0] - rollout_steps) // n_windows)))
                win_starts.append(starts[:n_windows])
            else:
                win_starts.append([0])
        for it in range(iters):
            opt.zero_grad()
            G = self.dictionary.features(Z, k)
            W = ridge_weights(G, Y, self.lamb)
            self.W = W.detach()

            L_step = torch.mean((Y - G @ W.T) ** 2) / yvar
            in_phase1 = two_phase and it < phase1_iters
            if in_phase1:
                L = L_step
                L_roll = L_fp = L_spec = torch.zeros((), dtype=dtype, device=dev)
            else:
                if sched is None and phase2_iters > 1:
                    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                        opt, T_max=phase2_iters,
                        eta_min=max(phase2_lr / 1000.0, 1e-6))
                # multi-window rollout on the validation trajectory with
                # periodic re-warming and bounded (tanh-clipped) error.
                errs = []
                for Vbuf, V, starts in zip(Vbufs, Vs, win_starts):
                    for s in starts:
                        buf = Vbuf[s : s + 1].clone()
                        Vtarget = V[k + s : k + s + roll_now]
                        for t in range(roll_now):
                            Gb = self.dictionary.features(buf, k)
                            xnew = buf[:, 0:4] + Gb @ W.T
                            e = xnew[0] - Vtarget[t]
                            errs.append(clip_scale * torch.tanh(e / clip_scale))
                            if t + 1 < roll_now:
                                buf[:, 4:] = buf[:, :-4].clone()
                                buf[:, 0:4] = xnew
                L_roll = torch.mean(torch.stack(errs) ** 2) / yvar

                # fixed-point drift + spectral radius at observed attractors
                L_fp = torch.zeros((), dtype=dtype, device=dev)
                L_spec = torch.zeros((), dtype=dtype, device=dev)
                for a in att:
                    xa = torch.cat([a, torch.zeros(2, dtype=dtype, device=dev)])
                    xk = xa.repeat(k)
                    Gx = self.dictionary.features(xk[None, :], k)
                    drift = Gx @ W.T
                    L_fp = L_fp + torch.mean(drift ** 2)
                    Jg = self.dictionary.jacobian_newest(xa, k)
                    J = torch.eye(4, dtype=dtype, device=dev) + Jg.T @ W.T
                    ev = torch.linalg.eigvals(J)
                    rho = torch.max(torch.abs(ev))
                    L_spec = L_spec + torch.relu(rho - rho_target) ** 2
                L_fp = L_fp / len(att)
                L_spec = L_spec / len(att)
                L = L_step + a1 * L_roll + a2 * L_fp + a3 * L_spec
            L.backward()
            # physical bounds on the dictionary parameters
            for name, p in self.dictionary.named_parameters():
                if name == "centers":
                    p.data.clamp_(-2.0, 2.0)
                elif name == "logh":
                    p.data.clamp_(np.log(self.dictionary.h_min + 1e-6),
                                  np.log(3.0))
            torch.nn.utils.clip_grad_norm_(self.dictionary.parameters(),
                                           grad_clip)
            opt.step()
            if sched is not None:
                sched.step()
            roll_now = min(rollout_steps, int(roll_now * roll_growth))
            hist.append((L.item(), L_step.item(), L_roll.item(),
                         L_fp.item(), L_spec.item()))
            if verbose and (it % verbose == 0 or it == iters - 1):
                print(f"it {it:4d} L {L.item():.4f} step {L_step.item():.4f} "
                      f"roll {L_roll.item():.4f} fp {L_fp.item():.4f} "
                      f"spec {L_spec.item():.4f}")
            if callback is not None:
                callback(it, self)

        # final weights
        with torch.no_grad():
            G = self.dictionary.features(Z, k)
            self.W = ridge_weights(G, Y, self.lamb).cpu().numpy()
        self.dict_np = {
            "centers": self.dictionary.centers.detach().cpu().numpy(),
            "heights": self.dictionary.heights.detach().cpu().numpy(),
        }
        return np.array(hist), self.W

    def feature_fn_numpy(self):
        """Return a numpy feature function for basin prediction."""
        k = self.k
        centers = self.dictionary.centers.detach().cpu().numpy()
        heights = self.dictionary.heights.detach().cpu().numpy()
        kind = type(self.dictionary).__name__

        def fn(Z):
            n = len(Z)
            parts = [np.ones((n, 1)), Z]
            for i in range(k):
                r = Z[:, 4 * i : 4 * i + 2]
                if kind == "PointSourceFeatures":
                    d = centers[None, :, :] - r[:, None, :]
                    d3 = (np.sum(d * d, axis=-1, keepdims=True) +
                          heights[None, :, None] ** 2) ** 1.5
                    parts.append((d / d3).reshape(n, 2 * len(centers)))
                else:
                    d2 = np.sum((r[:, None, :] - centers[None, :, :]) ** 2, axis=-1)
                    parts.append((d2 + heights[None, :] ** 2) ** (-1.5))
            return np.hstack(parts)

        return fn


def make_delay(S, k):
    T = len(S)
    n = T - k + 1
    return np.column_stack([S[k - 1 - i : T - i] for i in range(k)])
