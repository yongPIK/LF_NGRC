"""Sensitivity curve and fixed-attractor-init model (Fig. 3a / Section 4.3).

NOTE on the archived curve: the exact perturbation protocol used to generate
the canonical ``data/fig_sensitivity.npy`` (the curve plotted in Fig. 3a and
quoted in Sec. 4.3) was not preserved. This script reproduces the same seven
delta values with a fresh random direction per delta (rng seed 0); the
small-delta points agree with the archive, while the large-delta tail depends
on the unrecorded perturbation direction. The figures and the text therefore
use the archived file, and the script's output (written to ./outputs/) is a
reproducible approximation of the same protocol.

Computes and saves:
  * data/fig_sensitivity.npy : basin error p vs magnet-center perturbation
    delta (7 values, delta = 0 .. 5e-2), exact features with perturbed
    centers; expected values (0.23, 0.42, 0.48, 0.51, 0.54, 0.61, 0.78) are
    those already saved in data/fig_sensitivity.npy (the archive is the
    canonical figure source);
  * data/fig_attinit_p.npy   : p of the model whose point-source centers are
    FIXED at the observed settling points (only the readout is ridge-fitted);
  * prints the settling-point / magnet distances (~0.018-0.041) and the
    spectral radius of the fixed-attractor map at the settling points
    (rho ~ 2.9), the mechanism behind its failure.
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time, json
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp
from run_lfngrc import make_data
from lf_ngrc import detect_attractors

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
H = 0.2


def exact_force_features(Z, k, centers, h=H):
    """Bias + delays + exact force features (c_j - r)/D_j^3 for given centers."""
    n = len(Z)
    parts = [np.ones((n, 1)), Z]
    for i in range(k):
        r = Z[:, 4 * i : 4 * i + 2]
        d = centers[None, :, :] - r[:, None, :]
        d3 = (np.sum(d * d, axis=-1, keepdims=True) + h * h) ** 1.5
        parts.append((d / d3).reshape(n, 2 * len(centers)))
    return np.hstack(parts)


def train_centers(trajs, k, centers, lamb=1e-4, h=H):
    """Ridge readout with point-source centers held fixed."""
    GG = GY = None
    for S in trajs:
        Z = rp.make_delay_states(S, k)[:-1]
        G = exact_force_features(Z, k, centers, h)
        Y = S[k:] - S[k - 1 : -1]
        if GG is None:
            m = G.shape[1]
            GG = np.zeros((m, m))
            GY = np.zeros((m, 4))
        GG += G.T @ G
        GY += G.T @ Y
    return np.linalg.solve(GG + lamb * np.eye(GG.shape[0]), GY).T


def paper_jacobian(W, centers, a4, h=H, eps=1e-6):
    """J = I_d + W dg/dx_t at [x_t, a, a] (newest-delay derivative; Sec. 3.3)."""
    def H(x_t):
        return exact_force_features(np.hstack([x_t, a4, a4])[None, :],
                                    3, centers, h).ravel()
    m = exact_force_features(np.zeros((1, 12)), 3, centers, h).shape[1]
    dg = np.zeros((m, 4))
    for i in range(4):
        e = np.zeros(4)
        e[i] = eps
        dg[:, i] = (H(a4 + e) - H(a4 - e)) / (2 * eps)
    return np.eye(4) + W @ dg


def spectral_radius(J):
    return float(np.max(np.abs(np.linalg.eigvals(J))))


def main(grid=101, outdir=None, seed=0, deltas=None):
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    t0 = time.time()
    k, dt = 3, 0.01
    trajs, _, _ = make_data(10, 2000, dt, k, seed)
    gt_path = os.path.join(outdir, "gt101.npy")
    if not os.path.exists(gt_path):
        alt = os.path.join(PKG, "data", "gt101.npy")
        if os.path.exists(alt):
            gt_path = alt
    gridv = np.linspace(-1.5, 1.5, grid)
    gt = np.load(gt_path) if os.path.exists(gt_path) else \
        rp.ground_truth_basins(gridv, gridv, dt=dt)

    att = detect_attractors(trajs, k)
    dmin = np.min(np.linalg.norm(att[:, None, :] - rp.MAGNETS[None, :, :],
                                 axis=-1), axis=1)
    print("observed settling points:", np.round(att, 4))
    print("settling-point/magnet distances:", np.round(dmin, 4),
          f"({time.time()-t0:.0f}s)")

    # --- sensitivity curve -------------------------------------------------
    if deltas is None:
        deltas = [0.0, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 5e-2]
    rng = np.random.default_rng(0)
    ps = []
    for delta in deltas:
        if delta == 0.0:
            centers = rp.MAGNETS
        else:
            u = rng.normal(size=3)
            u /= np.linalg.norm(u)
            centers = rp.MAGNETS + delta * u[:, None]
        W = train_centers(trajs, k, centers)
        pred = rp.predict_basins(W, lambda Z: exact_force_features(Z, k,
                                                                   centers),
                                 k, gridv, gridv, dt)
        p, _ = rp.error_rate(pred, gt)
        ps.append(float(p))
        print(f"delta {delta:.0e}: p = {p:.4f}  ({time.time()-t0:.0f}s)")
    np.save(os.path.join(outdir, "fig_sensitivity.npy"),
            np.array([deltas, ps]))

    # --- fixed-attractor-init model ---------------------------------------
    Wf = train_centers(trajs, k, att)
    predf = rp.predict_basins(Wf, lambda Z: exact_force_features(Z, k, att),
                              k, gridv, gridv, dt)
    pf, _ = rp.error_rate(predf, gt)
    np.save(os.path.join(outdir, "fig_attinit_p.npy"), np.array([pf]))
    att_full = np.hstack([att, np.zeros((len(att), 2))])   # [x,y,0,0]
    rhos = [spectral_radius(paper_jacobian(Wf, att, a)) for a in att_full]
    print(f"fixed-attractor init: p = {pf:.4f}  "
          f"spectral radius at settling points = {np.round(rhos,3)} "
          f"({time.time()-t0:.0f}s)")
    with open(os.path.join(outdir, "attinit_diagnostics.json"), "w") as f:
        json.dump({"p": pf, "distances_to_magnets": dmin.tolist(),
                   "spectral_radii": rhos}, f, indent=1)
    print(f"saved fig_sensitivity.npy / fig_attinit_p.npy to {outdir}")
    return {"deltas": deltas, "ps": ps, "p_attinit": pf, "distances": dmin,
            "rho_attinit": rhos}


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--grid", type=int, default=101)
    ap.add_argument("--out", default=None)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    main(grid=args.grid, outdir=args.out, seed=args.seed)
