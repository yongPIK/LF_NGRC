"""Figure 3: over-complete J=4 dictionary (merged three-panel figure).

Panels: (a) J=4 basin prediction; (b) learned sources vs true magnets;
(c) error rate p vs dictionary size J (LF-NGRC closed loop, 20 seeds,
51x51 grid) from outputs/sweeps/j_J*.json.

Run:  python plot_j4.py
"""

import os
import sys
import json
import glob
import numpy as np
import matplotlib
if os.environ.get("LF_HEADLESS") == "1":
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
DATA = os.environ.get("LF_DATA", os.path.join(PKG, "data"))
SWEEP_DIR = os.path.join(HERE, "outputs", "sweeps")
OUT = os.environ.get("LF_FIGOUT", os.path.join(HERE, "outputs", "figures"))
os.makedirs(OUT, exist_ok=True)

P_RANDOM, P_USEFUL = 2.0 / 3.0, 0.45


def load_j_sweep():
    """Return {J: [p per seed]} from outputs/sweeps/j_J*.json."""
    out = {}
    for path in glob.glob(os.path.join(SWEEP_DIR, "j_J*_s*.json")):
        stem = os.path.basename(path)[:-5]
        key = stem.rsplit("_s", 1)[0]          # e.g. "j_J4"
        j = int(key.split("_J")[1])
        with open(path, "r", encoding="utf-8") as f:
            res = json.load(f)
        v = res.get("lf_closed", res.get("p"))
        if v is not None:
            out.setdefault(j, []).append(v)
    return out


def main():
    pred = np.load(os.path.join(DATA, "lf_J4_pred.npy"))
    centers = np.load(os.path.join(DATA, "lf_J4_centers.npy"))
    heights = np.load(os.path.join(DATA, "lf_J4_heights.npy"))
    jsweep = load_j_sweep()

    fig, axes = plt.subplots(1, 3, figsize=(14.0, 4.2),
                             constrained_layout=True)

    # ---------------- (a) basin map ----------------
    ax = axes[0]
    cmap = ListedColormap(["black", "#2166ac", "#fdae61", "#1a9850"])
    norm = BoundaryNorm([-1.5, -0.5, 0.5, 1.5, 2.5], cmap.N)
    img = np.where(pred == -2, -1, pred)
    ax.imshow(img, origin="lower", extent=[-1.5, 1.5, -1.5, 1.5],
              cmap=cmap, norm=norm)
    ax.set_title("(a) LF-NGRC basins, $J=4$")
    ax.set_xlabel("$x_0$")
    ax.set_ylabel("$y_0$")

    # ---------------- (b) learned sources vs magnets ----------------
    ax = axes[1]
    mags = rp.MAGNETS
    ax.scatter(mags[:, 0], mags[:, 1], marker="*", s=260, c="#000000",
               label="true magnets ($h=0.2$)", zorder=5)
    ax.scatter(centers[:, 0], centers[:, 1], s=140, facecolors="none",
               edgecolors="#d6604d", linewidths=1.8,
               label="learned sources", zorder=4)
    hs = ", ".join(f"{h:.3f}" for h in heights)
    ax.text(-1.55, 1.05, f"learned $h^*$:\n{hs}\ntrue $h = 0.200$",
            fontsize=8, va="top",
            bbox=dict(facecolor="white", alpha=0.85, edgecolor="0.5"))
    ax.annotate("redundant pair", xy=(-0.31, -0.52), xytext=(-0.95, -1.32),
                fontsize=9, arrowprops=dict(arrowstyle="->", lw=1))
    ax.set_xlim(-1.6, 1.6)
    ax.set_ylim(-1.6, 1.6)
    ax.set_aspect("equal")
    ax.set_title("(b) Learned sources vs magnets")
    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")
    ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), fontsize=8)
    ax.text(0.35, 1.32, "basin error $p = 0.237$",
            fontsize=9, bbox=dict(facecolor="white", alpha=0.8))

    # ---------------- (c) p vs dictionary size J ----------------
    ax = axes[2]
    xs = sorted(jsweep)
    yy = [np.mean(jsweep[j]) for j in xs]
    ee = [np.std(jsweep[j], ddof=1) for j in xs]
    ax.errorbar(xs, yy, yerr=ee, color="#d62728", marker="s", ls="-",
                lw=1.5, ms=5, capsize=3,
                label="LF-NGRC (closed loop)")
    ax.axhline(P_RANDOM, color="0.45", ls=":", lw=1.2)
    ax.axhline(P_USEFUL, color="0.45", ls="--", lw=1.2)
    ax.text(xs[-1], P_RANDOM + 0.02, "Random guess", ha="right",
            fontsize=8, color="0.3")
    ax.text(xs[-1], P_USEFUL + 0.02, "Useful prediction", ha="right",
            fontsize=8, color="0.3")
    ax.set_xticks(xs)
    ax.set_xlabel("Dictionary size $J$")
    ax.set_ylabel("Error rate $p$")
    ax.set_ylim(0.0, 0.85)
    ax.grid(alpha=0.25, lw=0.5)
    ax.legend(fontsize=8, frameon=False, loc="upper right")

    out = os.path.join(OUT, "fig3_J4_overcomplete.png")
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print("saved", out)
    print("  p vs J:", {j: round(float(np.mean(jsweep[j])), 4)
                        for j in xs})


if __name__ == "__main__":
    main()
