"""Spectral-radius diagnostics at the observed settling points.

Computes, for the exact, LF-NGRC closed-loop (learned dictionary + ridge
refit), and fixed-attractor models, the spectral radius rho and
sigma_min(I-J) of the map Jacobian J(a_i) = I_d + W dg/dx_t |_{a_i} -- the
quantity used by the spectral term in the closed-loop objective (Section 3.3),
with dg/dx_t the derivative w.r.t. the newest delayed state only.

Results (seed 0):
  * exact and LF closed-loop maps are locally stable (rho ~ 0.98);
  * the fixed-attractor map is locally UNSTABLE (rho ~ 2.9) -- the mechanism
    behind its failure (p ~ 0.66);
  * sigma_min(I-J) ~ 1e-3..1e-2 in all cases.

Both the observed settling points (what the spectral term uses) and the map's
own true fixed points (root-found) are reported. Output:
data/spectral_diagnostics.json.
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time, json
import numpy as np
from scipy.optimize import root

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp
from run_lfngrc import make_data, train_exact
from lf_ngrc import detect_attractors

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
H = 0.2


def point_source_features(Z, k, centers, heights):
    """Bias + delays + point-source force features (matches lf_ngrc)."""
    n = len(Z)
    parts = [np.ones((n, 1)), Z]
    for i in range(k):
        r = Z[:, 4 * i : 4 * i + 2]
        d = centers[None, :, :] - r[:, None, :]
        h2 = heights[None, :, None] ** 2
        d3 = (np.sum(d * d, axis=-1, keepdims=True) + h2) ** 1.5
        parts.append((d / d3).reshape(n, 2 * len(centers)))
    return np.hstack(parts)


def ridge_refit(Ztr, Ytr, feature_fn, lamb=1e-4):
    G = feature_fn(Ztr)
    return np.linalg.solve(G.T @ G + lamb * np.eye(G.shape[1]),
                           (G.T @ Ytr)).T


def map_true_fixed_points(W, feature_fn, starts, eps=1e-6):
    """Roots of x -> W g([x,x,x]): the map's own fixed points near starts."""
    out = []
    for s in starts:
        a4 = np.hstack([s[:2], [0.0, 0.0]])

        def h(x):
            Z = np.tile(x, 3)[None, :]
            return (W @ feature_fn(Z).T).ravel()
        sol = root(lambda x: h(x), a4, method="hybr", tol=1e-12)
        out.append(sol.x)
    return np.array(out)


def paper_jacobian(W, feature_fn, a4, eps=1e-6):
    """J = I_d + W dg/dx_t at delay state [x_t, a, a] (newest derivative)."""
    def H(x_t):
        return feature_fn(np.hstack([x_t, a4, a4])[None, :]).ravel()
    m = feature_fn(np.zeros((1, 12))).shape[1]
    dg = np.zeros((m, 4))
    for i in range(4):
        e = np.zeros(4)
        e[i] = eps
        dg[:, i] = (H(a4 + e) - H(a4 - e)) / (2 * eps)
    return np.eye(4) + W @ dg


def spectrum(J):
    rho = float(np.max(np.abs(np.linalg.eigvals(J))))
    smin = float(np.min(np.linalg.svd(np.eye(4) - J, compute_uv=False)))
    return rho, smin


def main(outdir=None, seed=0):
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    t0 = time.time()
    k, dt, lamb = 3, 0.01, 1e-4
    trajs, _, _ = make_data(10, 2000, dt, k, seed)
    Ztr = np.concatenate([rp.make_delay_states(S, k)[:-1] for S in trajs])
    Ytr = np.concatenate([S[k:] - S[k - 1 : -1] for S in trajs])
    att = detect_attractors(trajs, k)
    print("observed settling points:", np.round(att, 4),
          f"({time.time()-t0:.0f}s)")

    Wex = train_exact(trajs, k, dt, lamb)
    ex_fn = lambda Z: rp.exact_features(Z, k)

    summary_path = os.path.join(outdir, "summary.json")
    if not os.path.exists(summary_path):
        alt = os.path.join(PKG, "data", "summary.json")
        if os.path.exists(alt):
            summary_path = alt
    if os.path.exists(summary_path):
        s0 = json.load(open(summary_path))["0"]
        centers = np.array(s0["centers"])
        heights = np.array(s0["heights"])
    else:
        centers = att
        heights = np.full(3, 0.2)
    lf_fn = lambda Z: point_source_features(Z, k, centers, heights)
    Wlf = ridge_refit(Ztr, Ytr, lf_fn, lamb)

    fx_fn = lambda Z: point_source_features(Z, k, att, np.full(3, H))
    Wfx = ridge_refit(Ztr, Ytr, fx_fn, lamb)

    models = {"exact": (Wex, ex_fn), "lf_closed": (Wlf, lf_fn),
              "fixed_attractor": (Wfx, fx_fn)}
    out = {"definition": "J(a)=I_d + W dg/dx_t (newest delayed state)",
           "models": {}}
    for name, (W, fn) in models.items():
        fp = map_true_fixed_points(W, fn, att)
        rows = []
        for label, pts in (("observed_settling", att), ("true_fixed_point", fp)):
            for p in pts:
                a4 = np.hstack([p[:2], [0.0, 0.0]])
                rho, smin = spectrum(paper_jacobian(W, fn, a4))
                rows.append({"point_type": label, "point": p[:2].tolist(),
                             "rho": rho, "sigma_min_I_minus_J": smin})
        out["models"][name] = rows
        print(f"{name}: " + ", ".join(
            f"{r['point_type'][:7]} rho={r['rho']:.4f} "
            f"smin={r['sigma_min_I_minus_J']:.4e}" for r in rows)
            + f" ({time.time()-t0:.0f}s)")
    with open(os.path.join(outdir, "spectral_diagnostics.json"), "w") as f:
        json.dump(out, f, indent=1)
    print(f"saved spectral_diagnostics.json to {outdir}")
    return out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    main(outdir=args.out, seed=args.seed)
