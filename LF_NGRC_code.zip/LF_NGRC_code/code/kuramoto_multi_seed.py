"""20-seed Kuramoto statistics: exact vs LF-NGRC (closed-loop) vs one-step.

Runs the standard Fig. 4 configuration (n=9, dt=0.01, k=2, lambda=1e-5,
Ntraj=200, Ntrain=3000, grid=101; closed-loop iters=1000, phase1=250,
rollout=400, clip=1.0) over a list of seeds, WITHOUT the gamma-sweep (the
sweep is only needed for the representative Fig. 4d), and saves per-seed
{gamma, acc_lf, gamma_onestep, acc_onestep, acc_exact} to
code/outputs/kuramoto_multi_seed20/kuramoto_seed{N}.json.

Run several workers in parallel (e.g. 5 x 4 seeds on a multi-core machine):
  python kuramoto_multi_seed.py --seeds 0 1 2 3
  python kuramoto_multi_seed.py --seeds 4 5 6 7
  ...
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import sys, json, argparse, time
import numpy as np
import torch

torch.set_num_threads(
    int(os.environ.get("LF_TORCH_THREADS", "4")))  # per-worker cap; several workers run in parallel
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kuramoto_lf as ku

N, DT, K, LAMB = 9, 0.01, 2, 1e-5
N_TRAJ, N_TRAIN = 200, 3000
GRID = 101
ITERS, PHASE1, ROLLOUT, CLIP = 1000, 250, 400, 1.0

# The 20 seeds used in the paper (converged runs, Sec. 4.4). Running without
# --seeds reproduces the reported statistics exactly.
DEFAULT_SEEDS = [0, 1, 2, 6, 10, 12, 13, 15, 17, 19,
                 20, 21, 23, 24, 25, 26, 27, 28, 30, 31]


def run_seed(seed, outdir):
    t0 = time.time()
    rng = np.random.default_rng(seed)
    S0 = rng.uniform(0.0, 2.0 * np.pi, (N_TRAJ, N))
    tmax = (N_TRAIN + K) * DT
    trajs = np.stack([ku.integrate_kuramoto(th, DT, tmax=tmax,
                                            return_full=True)[:, 0, :]
                      for th in S0])
    th0 = 2.0 * np.pi * 2 * np.arange(N) / N
    P1 = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1], dtype=float)
    P2 = np.array([0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=float)
    vrng = np.random.default_rng(1000 + seed)
    val_list = []
    for _ in range(3):
        a1, a2 = vrng.uniform(-np.pi, np.pi, 2)
        v0 = th0 + a1 * P1 + a2 * P2
        val_list.append(ku.integrate_kuramoto(v0, DT,
                                              tmax=(1200 + K) * DT,
                                              return_full=True)[:, 0, :])
    ku_gt, _, _ = ku.ground_truth_kuramoto(th0, P1, P2, DT, grid=GRID)

    Wex = ku._train_ngrc_ridge(trajs, K, LAMB,
                               lambda Z: ku.exact_features(Z, K))
    acc_exact = float(np.mean(ku._eval_slice(
        Wex, lambda Z: ku.exact_features(Z, K), K, N,
        th0, P1, P2, DT, grid=GRID) == ku_gt))
    print(f"[seed {seed}] exact acc {acc_exact:.4f} "
          f"{time.time()-t0:.0f}s", flush=True)

    dic = ku.SineFrequencyFeatures(gamma0=1.3)
    model = ku.KuramotoLF(dic, K, lamb=LAMB)
    _, Wlf = model.fit(trajs, val_list, rollout_steps=ROLLOUT, iters=ITERS,
                       lr=0.05, verbose=0, phase1_iters=PHASE1,
                       phase1_lr=0.02, clip_scale=CLIP, n_windows=5, a1=1.0)
    gamma = model.gamma_np
    acc_lf = float(np.mean(ku._eval_slice(
        Wlf, model.feature_fn_numpy(), K, N, th0, P1, P2, DT,
        grid=GRID) == ku_gt))
    print(f"[seed {seed}] LF gamma {gamma:.5f} acc {acc_lf:.4f} "
          f"{time.time()-t0:.0f}s", flush=True)

    dic1 = ku.SineFrequencyFeatures(gamma0=1.3)
    model1 = ku.KuramotoLF(dic1, K, lamb=LAMB)
    _, W1 = model1.fit(trajs, val_list, rollout_steps=ROLLOUT, iters=PHASE1,
                       lr=0.05, verbose=0, phase1_iters=PHASE1,
                       phase1_lr=0.02, clip_scale=CLIP, n_windows=5, a1=1.0)
    gamma1 = model1.gamma_np
    acc1 = float(np.mean(ku._eval_slice(
        W1, model1.feature_fn_numpy(), K, N, th0, P1, P2, DT,
        grid=GRID) == ku_gt))
    print(f"[seed {seed}] one-step gamma {gamma1:.5f} acc {acc1:.4f} "
          f"{time.time()-t0:.0f}s", flush=True)

    os.makedirs(outdir, exist_ok=True)
    res = {"seed": seed, "gamma": gamma, "acc_lf": acc_lf,
           "gamma_onestep": gamma1, "acc_onestep": acc1,
           "acc_exact": acc_exact}
    with open(os.path.join(outdir, f"kuramoto_seed{seed}.json"),
              "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1)
    print(f"[seed {seed}] done {time.time()-t0:.0f}s", flush=True)
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="*", default=DEFAULT_SEEDS,
                    help="seed list (default: the 20 paper seeds)")
    ap.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "outputs",
        "kuramoto_multi_seed20"))
    args = ap.parse_args()
    for s in args.seeds:
        run_seed(s, args.out)
    # aggregate mean +/- SD over the requested seeds
    import statistics
    res = {}
    for s in args.seeds:
        with open(os.path.join(args.out, f"kuramoto_seed{s}.json"),
                  encoding="utf-8") as f:
            res[s] = json.load(f)
    keys = ["acc_exact", "gamma", "acc_lf", "gamma_onestep", "acc_onestep"]
    agg = {k: {"mean": statistics.mean(res[s][k] for s in args.seeds),
               "std": statistics.stdev(res[s][k] for s in args.seeds)}
           for k in keys}
    agg["seeds"] = args.seeds
    agg["config"] = {"n": N, "dt": DT, "k": K, "lambda": LAMB,
                     "Ntraj": N_TRAJ, "Ntrain": N_TRAIN, "grid": GRID,
                     "iters": ITERS, "phase1_iters": PHASE1,
                     "rollout_steps": ROLLOUT, "clip_scale": CLIP}
    with open(os.path.join(args.out, "kuramoto_converged20_summary.json"),
              "w", encoding="utf-8") as f:
        json.dump(agg, f, indent=1)
    print("summary:", {k: (round(v["mean"], 4), round(v["std"], 4))
                       for k, v in agg.items() if isinstance(v, dict)})
