"""J=4 over-complete dictionary experiment (magnetic pendulum).

Shows that the source count need not be known a priori: with J=4 point sources
(one redundant, randomly placed), closed-loop learning automatically resolves
the redundancy and matches the exact-model basin error.

Modes:
  single  -- one run (default redundant-source placement), writes data/lf_J4_*
  nine    -- paper claim: 9 different redundant-source initializations (4
             corners, center, an observed fixed point, 3 random points), all
             expected to give p=0.237; writes data/lf_J4_initNN_* and
             data/lf_J4_nine_init_summary.json
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # Windows OpenMP fix
import sys, time, json, argparse
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import repro_catch22 as rp
from lf_ngrc import PointSourceFeatures, LFNGRC, detect_attractors
from run_lfngrc import make_data, eval_basins

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(seed=0, outdir=None, redundant_init=None, tag="", iters=1100,
        grid_size=101, trajs=None, att=None):
    """Train J=4 LF-NGRC with the redundant source initialized at
    `redundant_init` (2-vector) or, if None, at a fixed random point (rng 42).
    Files are saved with prefix lf_J4_<tag>_ (empty tag -> lf_J4_)."""
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    t0 = time.time()
    k, dt, lamb = 3, 0.01, 1e-4
    if trajs is None:
        trajs, _, S0 = make_data(10, 2000, dt, k, seed)
    if att is None:
        att = detect_attractors(trajs, k)
    vrng = np.random.default_rng(1000 + seed)
    vlist = []
    for _ in range(3):
        v0 = np.hstack([vrng.uniform(-1.5, 1.5, (1, 2)), np.zeros((1, 2))])
        vlist.append(rp.sample_trajectory(v0[0], dt, 1200 + k))
    print("observed attractors:", np.round(att, 4), f"{time.time()-t0:.0f}s")

    if redundant_init is None:
        rng = np.random.default_rng(42)
        redundant_init = rng.uniform(-1.0, 1.0, (1, 2))
    else:
        redundant_init = np.atleast_2d(np.asarray(redundant_init, dtype=float))
    init_c = np.vstack([att, redundant_init])
    dic = PointSourceFeatures(4, init_centers=init_c)
    model = LFNGRC(dic, k, lamb=lamb, seed=seed)
    hist, W = model.fit(trajs, vlist, rollout_steps=500, a1=1.0, a2=0.1,
                        a3=0.1, iters=iters, verbose=0, roll_min=30,
                        roll_growth=1.01, n_windows=6, two_phase=True,
                        phase1_iters=300, phase1_lr=0.01, phase2_lr=0.05,
                        init_attractors=False)
    centers = model.dict_np["centers"]
    heights = model.dict_np["heights"]
    print("learned J=4 centers:", np.round(centers, 5))
    print("heights:", np.round(heights, 5), f"{time.time()-t0:.0f}s")

    prefix = f"lf_J4_{tag}" if tag else "lf_J4"
    np.save(os.path.join(outdir, f"{prefix}_W.npy"), W)
    np.save(os.path.join(outdir, f"{prefix}_centers.npy"), centers)
    np.save(os.path.join(outdir, f"{prefix}_heights.npy"), heights)
    np.save(os.path.join(outdir, f"{prefix}_hist.npy"), hist)

    grid = np.linspace(-1.5, 1.5, grid_size)
    pred = eval_basins(W, model.feature_fn_numpy(), k, dt, grid)
    np.save(os.path.join(outdir, f"{prefix}_pred.npy"), pred)
    gt_path = os.path.join(outdir, "gt101.npy")
    if not os.path.exists(gt_path):
        alt = os.path.join(PKG, "data", "gt101.npy")
        if os.path.exists(alt):
            gt_path = alt
    gt = np.load(gt_path) if os.path.exists(gt_path) else \
        rp.ground_truth_basins(grid, grid, dt=dt)
    p, _ = rp.error_rate(pred, gt)
    print(f"LF-NGRC J=4: p = {p:.4f}  "
          f"unique {np.unique(pred, return_counts=True)} "
          f"({time.time()-t0:.0f}s)")
    with open(os.path.join(outdir, f"{prefix}_summary.json"), "w") as f:
        json.dump({"p": float(p), "centers": centers.tolist(),
                   "heights": heights.tolist(),
                   "redundant_init": redundant_init.tolist()}, f, indent=1)
    return p


def nine_initializations(seed=0, outdir=None, iters=1100, grid_size=101):
    """Run the 9 redundant-source initializations reported in Section 4.2."""
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "outputs")
    os.makedirs(outdir, exist_ok=True)
    k, dt = 3, 0.01
    trajs, _, _ = make_data(10, 2000, dt, k, seed)
    att = detect_attractors(trajs, k)
    rng = np.random.default_rng(7)
    positions = [
        [-1.5, -1.5], [1.5, -1.5], [1.5, 1.5], [-1.5, 1.5],   # corners
        [0.0, 0.0],                                            # center
        att[0].tolist(),                                       # observed fp
        rng.uniform(-1.0, 1.0, 2).tolist(),                    # 3 random
        rng.uniform(-1.0, 1.0, 2).tolist(),
        rng.uniform(-1.0, 1.0, 2).tolist(),
    ]
    results = {}
    for i, pos in enumerate(positions, start=1):
        print(f"--- redundant init {i}/9 at {np.round(pos,3)} ---", flush=True)
        p = run(seed=seed, outdir=outdir, redundant_init=pos,
                tag=f"init{i:02d}", iters=iters, grid_size=grid_size,
                trajs=trajs, att=att)
        results[f"init{i:02d}"] = {"redundant_init": pos, "p": float(p)}
    with open(os.path.join(outdir, "lf_J4_nine_init_summary.json"), "w") as f:
        json.dump(results, f, indent=1)
    print("nine-init summary:", {k2: v2["p"] for k2, v2 in results.items()})
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["single", "nine"], default="single")
    ap.add_argument("--out",
                    default=os.path.join(os.path.dirname(
                        os.path.abspath(__file__)), "outputs"))
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--iters", type=int, default=1100)
    ap.add_argument("--grid", type=int, default=101)
    args = ap.parse_args()
    if args.mode == "nine":
        nine_initializations(seed=args.seed, outdir=args.out,
                             iters=args.iters, grid_size=args.grid)
    else:
        run(seed=args.seed, outdir=args.out, iters=args.iters,
            grid_size=args.grid)
