"""Multi-seed MLP baselines for Table 3 (mean +/- std over seeds).

Runs the one-step and closed-loop MLP baselines on seeds 0..n_seeds-1 (same
data budget as LF-NGRC) and saves per-seed values plus mean/std to
code/outputs/sweeps/mlp_multi_seed_summary.json.

Run:  python mlp_multi_seed.py 
"""

import os
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import sys, time, json, argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import repro_catch22 as rp
import mlp_baseline as mb

CODE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(CODE)
OUT = os.path.join(CODE, "outputs", "sweeps")


def run_seed(seed, k=3, dt=0.01):
    t0 = time.time()
    trajs, vlist, Z, Y = mb.build_data(seed=seed)
    print(f"[seed {seed}] data ready {time.time()-t0:.0f}s", flush=True)

    m1, s1, mse1, r2_1 = mb.train_mlp_one_step(Z, Y, seed=seed, epochs=2000)
    grid = np.linspace(-1.5, 1.5, 101)
    pred1 = mb.predict_basins_map(m1, s1, k, grid, grid, dt)
    gt = np.load(os.path.join(PKG, "data", "gt101.npy"))
    p1, _ = rp.error_rate(pred1, gt)
    frac1 = float(np.mean(pred1 == -2))
    print(f"[seed {seed}] MLP one-step p={p1:.4f} MSE {mse1:.3e} "
          f"R2 {r2_1:.3f} ({time.time()-t0:.0f}s)", flush=True)

    m2, s2 = mb.train_mlp_closed_loop(Z, Y, vlist, k=k, seed=seed, epochs=400)
    pred2 = mb.predict_basins_map(m2, s2, k, grid, grid, dt)
    p2, _ = rp.error_rate(pred2, gt)
    frac2 = float(np.mean(pred2 == -2))
    print(f"[seed {seed}] MLP closed-loop p={p2:.4f} ({time.time()-t0:.0f}s)",
          flush=True)
    return {"seed": seed, "p_onestep": float(p1), "mse_onestep": float(mse1),
            "r2_onestep": float(r2_1), "frac_div_onestep": frac1,
            "p_closedloop": float(p2), "frac_div_closedloop": frac2}


def main(n_seeds, force):
    os.makedirs(OUT, exist_ok=True)
    per_seed = []
    for seed in range(n_seeds):
        path = os.path.join(OUT, f"mlp_seed{seed}.json")
        if os.path.exists(path) and not force:
            with open(path, "r", encoding="utf-8") as f:
                res = json.load(f)
            print(f"skip seed {seed} (exists)", flush=True)
        else:
            res = run_seed(seed)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(res, f, indent=1)
        per_seed.append(res)
    summary = {
        "n_seeds": n_seeds,
        "p_onestep_mean": float(np.mean([r["p_onestep"] for r in per_seed])),
        "p_onestep_std": float(np.std([r["p_onestep"] for r in per_seed],
                                      ddof=1)),
        "mse_onestep_mean": float(np.mean([r["mse_onestep"]
                                           for r in per_seed])),
        "p_closedloop_mean": float(np.mean(
            [r["p_closedloop"] for r in per_seed])),
        "p_closedloop_std": float(np.std(
            [r["p_closedloop"] for r in per_seed], ddof=1)),
        "per_seed": per_seed,
    }
    with open(os.path.join(OUT, "mlp_multi_seed_summary.json"), "w",
              encoding="utf-8") as f:
        json.dump(summary, f, indent=1)
    print("MLP one-step: %.4f +/- %.4f | closed-loop: %.4f +/- %.4f"
          % (summary["p_onestep_mean"], summary["p_onestep_std"],
             summary["p_closedloop_mean"], summary["p_closedloop_std"]),
          flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    main(args.seeds, args.force)
