"""Plot the spectral-penalty ablation (D3) figure, 20 seeds per setup.

Reads per-seed jsons from outputs/sweeps/d3_ablation/ and writes
figures/figD3_spectral_ablation.png (and paper/figures/ copy).

Run:  python plot_spectral_ablation.py
"""

import os
import json
import glob

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
ABL = os.path.join(HERE, "outputs", "sweeps", "d3_ablation")

BLUE = "#2166ac"
RED = "#d6604d"
EX_C = "#333333"
OS_C = "#888888"
NSEED = 20


def load(fname):
    p = os.path.join(ABL, fname)
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))


def main():
    defaults, ablated = [], []
    for N in (10, 100):
        for s in range(NSEED):
            d = load(f"default_ntr{N}_s{s}.json")
            if d is not None:
                defaults.append((N, s, d["p"], d["rho"]))
            a = load(f"ablated_ntr{N}_s{s}.json")
            if a is not None:
                ablated.append((N, s, a["p"], max(a["rho"])))

    # one representative point per reference model (main config: N_traj=10,
    # seed 0); two points per model overlap and clutter the figure.
    refs = []
    for mode in ("exact", "onestep"):
        d = load(f"{mode}_ntr10_s0.json")
        if d is not None:
            refs.append((mode, d["p"], max(d["rho"])))

    fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.6))

    ax = axes[0]
    for g, N in enumerate((10, 100)):
        pd_ = {r[1]: r[2] for r in defaults if r[0] == N}
        pa_ = {r[1]: r[2] for r in ablated if r[0] == N}
        seeds = sorted(set(pd_) & set(pa_))
        for i, s in enumerate(seeds):
            jit = (i - (len(seeds) - 1) / 2) * 0.012
            xd = g + jit - 0.18
            xa = g + jit + 0.18
            ax.scatter([xd], [pd_[s]], s=22, color=BLUE, zorder=3,
                       edgecolor="w", lw=0.3)
            ax.scatter([xa], [pa_[s]], s=22, marker="^", color=RED,
                       zorder=3, edgecolor="w", lw=0.3)
    ax.axhline(2 / 3, ls="--", color="k", lw=0.9)
    ax.axhline(0.45, ls=":", color="k", lw=0.9)
    ax.text(1.5, 2 / 3 + 0.012, "random guess", fontsize=8,
            ha="center")
    ax.text(1.5, 0.45 + 0.022, "useful threshold", fontsize=8,
            ha="center")
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["$N_{\\mathrm{traj}}=10$",
                        "$N_{\\mathrm{traj}}=100$"])
    ax.set_xlim(-0.85, 1.85)
    ax.set_ylim(0.15, 0.70)
    ax.set_ylabel("basin error rate $p$")
    ax.set_title("(a) Spectral-penalty ablation (20 seeds)", fontsize=10)
    ax.scatter([], [], s=22, color=BLUE, edgecolor="w", lw=0.3,
               label=r"LF closed, $\beta_3=0.1$")
    ax.scatter([], [], s=22, marker="^", color=RED, edgecolor="w",
               lw=0.3, label=r"LF closed, $\beta_3=0$")
    ax.legend(loc="upper left", fontsize=8)

    ax = axes[1]
    for r in defaults:
        ax.scatter([r[3]], [r[2]], s=22, color=BLUE, zorder=3,
                   edgecolor="w", lw=0.3)
    for r in ablated:
        ax.scatter([r[3]], [r[2]], s=22, marker="^", color=RED,
                   zorder=3, edgecolor="w", lw=0.3)
    for mode, p, rho in refs:
        mk = "o" if mode == "exact" else "s"
        ec = EX_C if mode == "exact" else OS_C
        ax.scatter([rho], [p], s=70, marker=mk, facecolors="none",
                   edgecolors=ec, lw=1.6, zorder=4)
    ax.axvline(1.0, color="k", ls="--", lw=1.0)
    ax.axvspan(1.0, 1.9, color=RED, alpha=0.06)
    ax.text(1.42, 0.56, r"$\rho>1$: locally unstable", fontsize=8,
            color=RED)
    ax.set_xlabel(r"spectral radius $\rho$ at observed fixed points")
    ax.set_ylabel("basin error rate $p$")
    ax.set_xlim(0.95, 1.9)
    ax.set_ylim(0.20, 0.70)
    ax.set_title("(b) Failure coincides with $\\rho>1$ (20 seeds)",
                 fontsize=10)
    ax.scatter([], [], s=22, color=BLUE, edgecolor="w", lw=0.3,
               label=r"LF closed, $\beta_3=0.1$")
    ax.scatter([], [], s=22, marker="^", color=RED, edgecolor="w",
               lw=0.3, label=r"LF closed, $\beta_3=0$")
    ax.scatter([], [], s=70, marker="o", facecolors="none",
               edgecolors=EX_C, lw=1.6,
               label="exact nonlinearity (ref)")
    ax.scatter([], [], s=70, marker="s", facecolors="none",
               edgecolors=OS_C, lw=1.6,
               label="LF-NGRC one-step (ref)")
    ax.legend(loc="lower right", fontsize=8)

    fig.suptitle("D3: removing the spectral penalty ($\\beta_3=0$) "
                 "destabilises closed-loop LF-NGRC "
                 "(20 seeds each, 51$\\times$51 grid)", fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    outdirs = [os.path.join(PKG, "figures")]
    for od in outdirs:
        os.makedirs(od, exist_ok=True)
        out = os.path.join(od, "figD3_spectral_ablation.png")
        fig.savefig(out, dpi=300)
        print("saved", out)


if __name__ == "__main__":
    main()
